"""Classical simulated annealing of a one-hot QUBO dispatch selection."""
import math,random

def benchmark(candidates,seed=71,iterations=2000):
    valid=[v for v in candidates if v['feasible']]
    if not valid:return {'status':'NO_FEASIBLE_CANDIDATES'}
    scores=[a['score'] for a in valid];minimum=min(scores);scale=max(1,max(scores)-minimum)
    normalized=[(s-minimum)/scale for s in scores];penalty=2.;n=len(valid)
    def energy(bits):return sum(c*b for c,b in zip(normalized,bits))+penalty*(sum(bits)-1)**2
    rng=random.Random(seed);bits=[0]*n;bits[0]=1;value=energy(bits);best=list(bits);best_e=value
    for step in range(iterations):
        temperature=max(.002,.5*(1-step/iterations));i=rng.randrange(n);trial=list(bits);trial[i]=1-trial[i];e=energy(trial)
        if e<value or rng.random()<math.exp(min(0,(value-e)/temperature)):bits=trial;value=e
        if sum(bits)==1 and value<best_e:best=list(bits);best_e=value
    selected=best.index(1);exact=min(range(n),key=lambda k:scores[k])
    return {'status':'BENCHMARKED','candidates':n,'iterations':iterations,'selected_index':selected,'annealed_score':scores[selected],
            'exact_discrete_score':scores[exact],'objective_gap':scores[selected]-scores[exact],
            'one_hot_valid':sum(best)==1,'qubo':'sum(normalized_score_i * x_i) + 2 * (sum(x_i)-1)^2',
            'method':'classical simulated annealing; quantum-inspired formulation only; no quantum hardware or quantum advantage',
            'authority':'benchmark only; verified classical horizon planner retains execution authority'}
