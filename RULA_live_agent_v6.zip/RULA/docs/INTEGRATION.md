# Transition from research to operational integration

The research modules are runnable. Actual plant and market integration requires authorized data, equipment definitions and execution permissions; these cannot be inferred from public weather or a synthetic portfolio.

1. Configure actual coordinates, capacities and shading horizons. Map complete SCADA asset IDs to the research asset contract. Supply timestamped GOOD-quality power, actual demand and both BESS SOC/health readings through the advisory API. Reconcile time zones, limits and source quality before trusting any recommendation.
2. Public weather and satellite adapters are connected. For multi-site operational work, fetch each site separately; the current weather advisory applies one location to the illustrative fleet. Calibrate hub-height wind, turbine power curves, irradiance-to-AC generation, terrain shadowing and satellite latency against instruments. Raw cloud raster ingestion requires geographic alignment and a defensible cloud-fraction extraction method.
3. Replace synthetic health and neural/vision/GNN training data with authorized labeled datasets. Use chronological held-out evaluation, real ramp/fault events, imbalance-cost backtests, interval coverage and subgroup/site performance audits. Generated-image accuracy is not real asset-detection accuracy; trend RUL is not validated PHM.
4. Connect actual contracted market prices/settlement windows to advisory snapshots. Confirm buy/sell authority, tariffs, fees, price units, transmission limits and storage operating rules. The supplied simulator does not place real orders or implement exchange-specific rules.
5. Preserve advisory mode until shadow-operation tests demonstrate feasible dispatch and safe failure behavior. Real actuation needs authenticated adapters, approval identity, bounded command authority, idempotent equipment protocols, reconciliation, emergency stop independent of this application and operational recovery procedures.
6. Production infrastructure must add TLS, managed identities, secret rotation, backup/restore drills, resource limits, off-host audit protection and per-portfolio state ownership. The owner/viewer role mechanism is a local research implementation, not a complete enterprise identity service.

Source documentation reviewed during implementation:

- Weather API: https://open-meteo.com/en/docs
- Satellite radiation API, coverage and latency: https://open-meteo.com/en/docs/satellite-radiation-api
- Solar-position equations: https://gml.noaa.gov/grad/solcalc/solareqns.PDF

External services supply data and have their own availability and usage conditions. Own-code algorithms require no pretrained frameworks. A true large language model would require substantial model weights/training or a separate approved provider; the current grounded NLP and tiny language model do not represent an LLM.
