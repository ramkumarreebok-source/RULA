# Validation record and interpretation

## Automated checks

The delivered suite checks unit conversion/efficiency, battery bounds and power balance across 96 intervals, pre-execution approval, budget exhaustion, grid limits, checkpoint recovery and audit tampering. Added module checks exercise geographic day/night position, cloud translation/unknown borders, PHM known-slope extrapolation, image formats and held-out generated samples, risk-tail arithmetic, QUBO feasibility, graph/DC balance, stale/bad-quality telemetry, feed units/cache, copilot authority, proposal expiry, emergency-stop recovery and transaction rollback.

API integration checks start a real local threaded HTTP server with owner/viewer roles. They test token rejection, read-only viewer authority, exact decision-ID approval, emergency stop, concurrent requests with one idempotency key, conflicting key reuse, foreign Origin rejection, CSV/vision/cloud APIs, keyed audit seals, advisory isolation and static sample downloads.

`docs/backtest.json` records a 384-interval, four-day deterministic simulation across normal, storm, grid-outage and price-spike scenarios. Each interval is approved programmatically inside the test simulator, with a large research spending budget, and checked for zero power-balance error, SOC bounds and intact audit chains. It is an implementation stress check, not evidence of real trading returns or fault-prediction accuracy.

The dashboard JavaScript passes `node --check`, and DOM-reference checks verify no duplicate IDs or references to missing controls. Browser-based visual QA was unavailable: the build environment could not obtain a valid Chromium download. No rendered-browser validation is claimed.

## Live adapter smoke checks

Both fixed-host public adapters returned real provider responses for Chennai (13.0827 N, 80.2707 E) during the build on 2026-10-03. The observed weather timestamp was 10:00 UTC; the latest released satellite irradiance timestamp was 09:00 UTC. This confirms schema connectivity, not current availability, calibrated energy forecasts or ground-truth accuracy. Runtime responses retain their own observation/receipt times and staleness flags.

Deterministic feed-contract tests exercise response units and caching without relying on future provider availability. Runtime provider errors return explicit 502/unavailable responses and do not replace missing real data with synthetic values.

## Learned-model evidence

Vision trains on 240 generated patterns and evaluates a separate 90-pattern generated set. The neural generation benchmark trains on 600 generated physics profiles and evaluates 150 other generated profiles. The demonstration graph head trains on 360 generated feature/label examples and evaluates 120 generated examples. Reported metrics are specific to those generated distributions. They are not field validation, unbiased generalization evidence or guarantees of accuracy on real turbines/panels.

PHM is trend extrapolation, not a trained failure model. Financial uncertainty uses illustrative independent Gaussian disturbances. Forecast bounds and PHM intervals are heuristic. The one-step forecast MAE compares a stored prediction with a later simulated observation; source changes can invalidate comparisons and real data requires separate held-out study.

## Completion boundary

This version completes the runnable research implementation and its sample data workflows. Operational completion still requires actual plant and exchange identities, credentials/permissions, calibrated asset limits, real labeled datasets and deployment infrastructure. A true LLM, validated real-image CV/GNN, decentralized blockchain, quantum hardware, full meshed network power flow and distributed production HA are not represented as implemented by the lightweight demonstrators.

## Version 6 live-agent validation

The main interface is now a background live-data advisory loop and a real model connector. The v5 research simulator is isolated at `/research`. A real Chennai public-data cycle returned weather observed at 2026-10-03 13:15 UTC, satellite irradiance observed at 12:00 UTC, a constrained recommendation, one internal review task and an intact persisted live audit. The elapsed cycle was about 19.7 seconds. Source latency is visible and satellite data were not treated as current SCADA.

Added tests check autonomous background startup, separation from accelerated simulation, preservation of real observation timestamps in forecast evaluation, stale-source blocking, waiting for real telemetry, task acknowledgement without external execution, pause behavior, version identity and explicit model failure without a template fallback.

Ollama and OpenAI native tool-call round trips are exercised with deterministic protocol fixtures, including tool-result feedback and argument/authority validation. These tests do not run pretrained inference. The actual local model connection check failed because no model server is installed in the build environment; no OpenAI API credential was supplied. Actual model-generated conversation therefore remains unverified until a user configures one of those providers. The UI reports connection and inference verification separately.

The runtime uses model instructions, a bounded tool allowlist, strict argument checking, owner checks for task creation and a guard against certain unsupported external-action claims. These reduce failure modes but do not establish hallucination-free model output or operational safety. Live recommendations, financial assumptions and synthetic asset models still require site validation before practical use.
