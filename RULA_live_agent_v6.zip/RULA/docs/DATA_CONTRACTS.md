# RULA data contracts

## Fleet snapshot for advisory recommendations

Use the actual UTC timestamp of acquisition and send to POST `/api/telemetry`. The example generator creates a generated complete eight-asset snapshot with current time. It is a schema fixture, not real measurements. Identifiers must match the configured portfolio. Missing/duplicate assets, output beyond capacity, bad quality, nonfinite values, stale/future times, BESS SOC outside limits and invalid prices are rejected.

```json
{
  "timestamp": "2026-10-03T10:00:00Z",
  "provenance": "authorized gateway; replace with actual source",
  "assets": [
    {"id":"SOLAR-1", "output_mw":4.2, "quality":"GOOD"}
  ],
  "batteries": [
    {"id":"BESS-1", "soc_mwh":10, "health":1},
    {"id":"BESS-2", "soc_mwh":10, "health":1}
  ],
  "demand_mw":25,
  "buy_inr_kwh":7,
  "sell_inr_kwh":4,
  "grid_limit_mw":30,
  "cloud_fraction":0.4,
  "wind_ms":8,
  "carbon_kg_kwh":0.7
}
```

The shortened asset list above is illustrative; it must contain all five solar and three wind asset IDs in a real request. Observation freshness is checked against server UTC time. Advisory operation uses configured battery power/capacity and research remaining gross budget. It does not change stored SOC, spending, learning or dispatched time.

## CSV analysis

Required columns: `timestamp,asset_id,output_mw,capacity_mw,latitude,longitude`. Timestamp must include a UTC offset. Output range 0–capacity; finite numbers; coordinates in geographic ranges. A repeated (UTC timestamp, asset ID) in one upload is rejected. Results report sums grouped by interval, not a sum across time mislabeled as instantaneous power. CSV content is held in memory only. This is not a live telemetry substitute.

## Cloud fraction raster pair

```json
{
  "previous": [[0.1,0.1,0.8,0.1],[0.1,0.1,0.8,0.1],[0.1,0.1,0.8,0.1],[0.1,0.1,0.8,0.1]],
  "current": [[0.1,0.1,0.1,0.8],[0.1,0.1,0.1,0.8],[0.1,0.1,0.1,0.8],[0.1,0.1,0.1,0.8]],
  "interval_minutes":15,
  "pixel_km":2,
  "horizon_minutes":30
}
```

Grids must share dimensions, 4–64 pixels each way, values finite within 0–1. Rows go south and columns east. Translation is searched within ±3 pixels; the extrapolated cloud field contains null for unknown border pixels. This is a research nowcast, not calibrated cyclone/cloud evolution physics. Satellite point irradiance is not itself a cloud raster and cannot be uploaded as one without a defensible conversion.

## Health series

`observations` is a list of [operating hours, health fraction], at least three points. Hours strictly increase; fractions are 0–1. Flat or improving health does not produce a finite RUL. A degrading linear trend is extrapolated to the user threshold, with heuristic slope uncertainty. This requires validation for each failure mechanism before practical use.

For a per-site early warning, also supply `observation_time` with a UTC offset and `bounds` containing south, north, west, east latitude/longitude limits. The raster spans those bounds with rows southward. The result maps solar sites to pixels, combines advected cloud fractions with future solar geometry and configured horizon shading, and reports generation-ramp estimates and reserve/purchase review suggestions. Outside-raster and unknown-border sites remain explicitly unavailable. Cloud attenuation is illustrative and requires calibration.
