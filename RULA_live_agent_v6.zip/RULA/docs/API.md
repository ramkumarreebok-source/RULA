# RULA v5 API

All endpoints return JSON except `/` and sample downloads. POST bodies must be JSON objects and are limited to 1,500,000 bytes. Optional Authorization is `Bearer <token>`. POST accepts same-origin browser requests; an unrelated Origin is rejected. Mutation requests accept `Idempotency-Key` up to 128 characters. Responses: 400 invalid input/state, 401 token/role failure, 403 origin failure, 404 unknown route, 409 idempotency conflict, 413 oversized body, 502 external data unavailable.

| Route | Method | Purpose/body |
|---|---|---|
| `/api/state` | GET | Latest pending or executed state, analysis and audit |
| `/api/history` | GET | Up to 192 executed intervals |
| `/api/research` | GET | Latest risk/PHM/graph/neural/QUBO report |
| `/api/feeds` | GET | Previously fetched live feed results; does not fetch |
| `/api/metrics` | GET | Request/error counts, uptime and audit count |
| `/api/health` | GET | Process and audit status |
| `/api/step` | POST | `{}`; propose and simulate within authority, otherwise wait |
| `/api/approve` | POST | `{"decision_id":"<current pending ID>"}`; explicit owner simulation approval |
| `/api/scenario` | POST | `{"name":"normal"}`; normal, storm, price_spike, grid_outage |
| `/api/stop`, `/api/resume` | POST | `{}`; persistent emergency-stop control |
| `/api/budget` | POST | `{"budget_inr":2000000}`; cannot be below existing spending |
| `/api/assets` | POST | Complete eight-asset configuration; existing IDs, capacity_mw, latitude, longitude; optional elevation_m, horizon_deg |
| `/api/ask` | POST | `{"text":"what if wind falls 30%?"}`; read-only, 2000-character maximum |
| `/api/import` | POST | `{"csv":"timestamp,asset_id,...\n..."}`; dated analysis totals, no dispatch |
| `/api/telemetry` | POST | Complete fresh asset/BESS observation JSON; isolated one-step advisory |
| `/api/live/weather` | POST | `{"latitude":13.0827,"longitude":80.2707}`; provider model data |
| `/api/live/satellite` | POST | Same coordinates; satellite-derived irradiance series |
| `/api/live/advisory` | POST | `{}`; requires weather less than one hour old; forecast for synthetic portfolio |
| `/api/satellite/nowcast` | POST | `{"demo":true}` or raster pair contract |
| `/api/vision` | POST | `{"base64":"<ASCII PGM or uncompressed 24-bit BMP bytes>"}`; at most 1 MiB decoded image, 4–256 pixels per dimension |
| `/api/phm` | POST | `{"asset_id":"B1","observations":[[0,1],[100,0.99],[200,0.98]],"threshold":0.8}` |
| `/api/audit/seal` | POST | `{}`; owner only, requires independent RULA_AUDIT_KEY |
| `/api/audit/verify-seal` | POST | Previously returned seal; key must remain available |

Approval always names an existing pending proposal and is not accepted for an already executed action. Proposed telemetry recommendations have no execution endpoint. Browser sample downloads are under `/assets/sample_clean.pgm`, `/assets/sample_defect.pgm`, `/assets/sample_occlusion.pgm`, `/assets/sample_clouds.json`, `/assets/sample_observations.csv`.
