# RULA — Renewable Utility Reasoning & Learning Agent

Version 5 is a runnable research platform written with Python's standard library and browser-native JavaScript. It contains an own-code energy decision loop, online ML, a small neural benchmark, vision, PHM, graph analysis, quantum-inspired optimization, satellite/cloud tools, public-data adapters, grounded NLP and authority controls. No third-party Python packages, pretrained weights or agent frameworks are required.

Real plant control, real exchange trades and operationally validated predictions are outside this implementation. Public weather and satellite data are real external data; default assets, demand, prices and dispatched actions are simulated. The small language-model demonstrator is not an LLM.

## Start on Windows

1. Download and **extract** the ZIP. Open the extracted `RULA` folder containing `server.py`.
2. Ensure `python --version` reports Python 3.10 or newer.
3. Double-click `start_windows.bat`. If the browser opens before the server starts, refresh it.
4. Alternatively, type `cmd` in that folder's File Explorer address bar and run:

```bat
python server.py
```

Open http://127.0.0.1:8000. Keep the terminal open. Stop with Ctrl+C. If the port is busy, run `python server.py --port 8001` and use http://127.0.0.1:8001.

The launch helper explicitly checks for `server.py` so it cannot run from the wrong folder. Do not attempt to run from inside the ZIP preview.

## Try the complete research flow

- **Operations:** advance one 15-minute simulation interval, compare alternatives and the two-hour plan, test storm/price/grid scenarios, inspect battery and budget results, and ask the grounded copilot why it selected an action.
- **Intelligence lab:** inspect Monte Carlo VaR/CVaR assumptions, PHM trends, Bayesian shortage rates, online forecast error, a generated-data neural benchmark, graph propagation/DC flow, the QUBO benchmark, a convolution-feature vision classifier and cloud advection. Download the example PGM images or cloud JSON directly from the dashboard and upload them to their panels.
- **Live data & imports:** fetch weather and satellite-derived irradiance for Chennai or specified coordinates, inspect source timestamps and latency, and build a weather-driven generation advisory for the illustrative fleet. Upload CSV observations or a complete fresh telemetry JSON snapshot. Advisory inputs cannot actuate equipment or submit orders.
- **Configuration & audit:** change the gross spending budget and asset coordinates/capacities/horizon angles; inspect verification and hash-chain integrity. Emergency stop blocks simulated dispatch and survives restart. Resume explicitly.

Auto advance maps five wall-clock seconds to one simulated 15-minute interval. It does not bypass human approval. Approvals require the exact pending decision ID; proposals expire after five minutes. The copilot never approves or executes actions.

## What is implemented

| Area | Working implementation | Validation boundary |
|---|---|---|
| Agent control loop | Sense → forecast → plan → validate → approve → simulate → verify → learn | No external actuator or exchange adapter |
| Portfolio | 5×8 MW solar, 3×10 MW wind, 2×20 MWh/5 MW BESS, industrial load | Default assets and coordinates are synthetic |
| Planning | Approximate two-hour beam search, receding first action, 25-point local dispatch enumeration | Not a global continuous or stochastic-horizon optimum |
| Battery & finance | SOC bounds, charge/discharge efficiency, power bounds, gross budget, net export revenue, wear allowance | Synthetic wear and prices; no tax, settlement or market-rule calibration |
| Forecast ML | Geographic solar geometry, cloud/wind profiles, own normalized SGD residual correction; true next-step error tracking | Heuristic uncertainty envelope; not calibrated coverage |
| Neural benchmark | Own 3→8→1 MLP and backpropagation; generated train/holdout samples | Fixed illustrative 40 MW solar/30 MW wind fleet; benchmark only |
| Satellite & GIS | NOAA-style solar position, horizon shading, live satellite irradiance point adapter, raster-motion translation/advection | No native GeoTIFF/NetCDF decoder, DEM extraction, terrain wind model or downloaded imagery |
| Live weather | Fixed-host Open-Meteo current/hourly adapter, source units/time checks, cache, explicit errors | Numerical weather model, not ground measurement or SCADA |
| PHM/RUL | Linear health-trend extrapolation with heuristic slope uncertainty; custom health-series endpoint | Synthetic BESS health by default; no calibrated lifetime accuracy |
| Risk | Beta-Bernoulli event-rate update; Monte Carlo financial/shortage scenarios and VaR/CVaR | Illustrative independence/noise assumptions, not calibrated financial risk |
| Graph/GNN | Three-step fixed aggregation with own trained logistic demonstration head; lossless radial star DC flows | Synthetic topology and generated node-label training; no meshed AC solver |
| Vision | Own Sobel convolution features + trained softmax classifier; BMP/PGM upload | Generated training/holdout imagery only; no real-asset validity; JPEG/PNG require external decoders |
| NLP/language | Read-only grounded explanations, evidence, financial queries and percentage-drop counterfactuals; own tiny bigram language model | Bigram model is not an LLM; all numeric explanations remain grounded |
| Quantum research | Classical simulated annealing of one-hot QUBO, compared with exact candidate minimum | No quantum hardware, QAOA or quantum speedup claim |
| MIS/Six Sigma | Budget, revenue, net cost, carbon, unmet energy, next-step MAE, illustrative residual 3-sigma chart | Stationarity/independence not established; no capability claim |
| Cryptography/audit | SHA-256 linked dispatch/control records; optional externally keyed HMAC audit-head seals | Local audit, not decentralized consensus; database is not encrypted |
| Authority/security | Owner/viewer token roles, origin checks, pending IDs/expiry, emergency stop, idempotency, integrity checks | Local HTTP research service; TLS and production access management need deployment infrastructure |
| Runtime/scalability | Serialized state machine, SQLite WAL, concurrent HTTP readers, provider calls outside engine lock, metrics | Single portfolio/process; distributed multi-tenant HA not implemented |

## Model assumptions and units

Power is MW, stored energy is MWh, a dispatch interval is 0.25 hours, prices are INR/kWh. Interval purchase = import MW × 0.25 × 1000 × INR/kWh. Carbon = import MW × 0.25 × 1000 × kg/kWh.

Positive BESS MW discharges; negative MW charges. Charge/discharge efficiency is 95% in each direction, SOC 10–90%, and per-unit power 5 MW. Gross spending includes purchases and an illustrative wear allowance. Export revenue is tracked separately and does not replenish spending authority automatically. Demand above supply/grid capacity is explicitly recorded as unserved energy.

The planner retains 12 paths per step, branching over the five best local feasible actions. It considers grid, storage and gross budget constraints. Future mean generation includes the learned residual correction. If no full horizon is feasible, a feasible local action remains available with the horizon failure reported. A minimum-reserve penalty discourages very low SOC. Monte Carlo shortage frequency >20%, interval purchase >INR 40,000, unmet load, or a storm requires approval before simulated execution.

Synthetic solar uses per-site geographic solar position, cloud fraction, health and horizon shading. Wind uses a cubic cut-in/rated/cut-out curve. Elevation is recorded but does not imply a DEM-derived weather correction. Counterfactuals stress the selected action without promising that it remains feasible.

## Live data and telemetry

Click **Fetch weather** or **Fetch satellite irradiance** to contact the provider. Ten-minute caching limits duplicate weather requests. A failure returns an explicit error, never fake data. Satellite observations may lag by 30 minutes or multiple hours; stale flags are shown. Point irradiance is separate from uploaded cloud fraction rasters.

The weather advisory uses one location for the illustrative fleet, a fixed wind-shear exponent to 100 m, and GHI/1000 solar scaling. It does not replace the dispatch simulator. The data source's current licensing/usage conditions apply; check them before commercial use.

`/api/telemetry` accepts a **complete** asset snapshot with GOOD quality, timestamp no more than 30 minutes old (no more than two minutes in the future), actual demand/grid/prices and both BESS SOC/health observations. Recommendations are one-step and advisory only. BESS capacity/power currently use the configured reference hardware. See `docs/DATA_CONTRACTS.md` and generate a current schema example with:

```sh
python make_telemetry_example.py
```

The example contains generated measurements and current timestamps; it is not real plant telemetry. An authorized gateway can forward its existing JSON file with `python telemetry_client.py --file gateway.json --interval 900`; this client never rewrites timestamps. Set RULA_CLIENT_TOKEN if the server requires a token. CSV files are analysis inputs only. CSV parser allows 5000 rows, within the API's 1.5 MB request limit.

## Persistence, upgrade and recovery

State is stored in `rula.sqlite` in the folder where the application is launched. SQLite WAL may create companion files. Startup verifies both audit chains; corrupted logs block restore/execution. Checkpoints restore battery/time/finances, online learning, PHM observations and recent history. Configuration and emergency-stop controls are replayed after checkpoint restore. Pending proposals do not survive restart; create a fresh one before approval.

To preserve an earlier version's state, stop its server, copy its `rula.sqlite` into this extracted RULA folder, then start this version. Copy only after a clean stop; retain a separate backup. Existing v3/v4 audit tables are migrated automatically. Keep the previous version available until the new server starts correctly.

POST mutation clients may use `Idempotency-Key`. An executed dispatch and its replay response are committed in one SQLite transaction. Repeating that key returns the stored response; a different route/payload with the same key returns 409. Non-dispatch configuration changes and their request-replay records are not one atomic transaction and should be reconciled after an abrupt process failure.

An audit-persistence failure during dispatch rolls back the SQL transaction and restores the in-memory simulation state. SQLite and HTTP are not an equipment transaction protocol; none of this confers exactly-once real actuation.

## Access control and HMAC seals

Local unauthenticated mode is the default for your own computer. To enable roles on Windows Command Prompt:

```bat
set RULA_TOKEN=your-long-owner-secret
set RULA_VIEWER_TOKEN=your-separate-viewer-secret
python server.py
```

Enter the desired token in the dashboard's Configuration tab. Owner may mutate simulation/configuration; viewer may read and use advisory tools. Both tokens can access sensitive operational data, so do not share the owner token with viewers. Use HTTPS through authenticated infrastructure before remote deployment; the current server defaults to loopback.

For independently keyed audit-head attestations, set `RULA_AUDIT_KEY` to a secret at least 32 characters long, retained outside the project/database. POST `/api/audit/seal` returns HMAC-SHA256 of both audit heads/counts. Keep the seal off-host. POST `/api/audit/verify-seal` verifies an uploaded seal against the current external key. This is cryptographic attestation, not database encryption or a blockchain consensus network.

## Tests and Docker

```sh
python -m unittest discover -s tests -v
```

See `validation.json` for delivered test results and their limitations. External adapters are tested with deterministic contracts and a live Chennai smoke check; live data availability is not guaranteed by a past successful request. Browser visual verification could not be run in the build environment.

Docker is optional and installed separately:

```sh
docker build -t rula .
docker run --rm -p 127.0.0.1:8000:8000 -v rula-data:/data -e RULA_DATABASE=/data/rula.sqlite rula
```

This binding exposes the container only to the local machine. Do not run multiple engines against the same portfolio database; a single process owns each mutable state. Use separate portfolio databases/processes for isolated research runs.

Documentation: `docs/ARCHITECTURE.md`, `docs/API.md`, `docs/DATA_CONTRACTS.md`, `docs/INTEGRATION.md`, `docs/VALIDATION.md`. Original v2 code is retained under `legacy_v2/` solely as reference; it is not the application entry point and its dependency requirements do not apply to this core.
