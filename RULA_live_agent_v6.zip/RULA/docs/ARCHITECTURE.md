# RULA architecture

The simulator is the only execution domain. Public feeds and uploaded telemetry are separate advisory domains with provenance. The copilot is read-only. One mutable portfolio state is owned by one process and serialized by a lock; network requests run outside that lock.

```mermaid
flowchart TD
  UI["Dashboard and API"] --> SIM["Simulation state machine"]
  UI --> DATA["Validated advisory inputs"]
  DATA --> GEO["Weather, satellite and geometry"]
  SIM --> FORECAST["Physics and online ML"]
  FORECAST --> PLAN["Horizon planner"]
  PLAN --> GATE["Budget, SOC and authority gate"]
  GATE --> EXEC["Simulated execution"]
  EXEC --> VERIFY["Balance and audit"]
  VERIFY --> SIM
  PLAN --> LAB["Risk, PHM, graph and QUBO lab"]
  LAB --> UI
  GEO --> UI
```

Core module: `core.py`. Inputs: `datafeeds.py`, `geospatial.py`, `research.py`. Learning/research: `neural.py`, `vision.py`, `healthrisk.py`, `quantum_research.py`. Read-only explanation: `copilot.py`. Local HTTP/auth/idempotency: `server.py`. Keyed integrity: `integrity.py`. Native browser interface: `web/index.html`.

SQLite tables:

| Table | Role |
|---|---|
| audit | SHA-256 linked dispatch/checkpoint records |
| controls | Separately linked proposals, approvals, scenario/configuration and emergency-stop records |
| requests | Persistent response replay indexed by idempotency key |

Dispatch audit insertion and executed response replay are one transaction. A failed dispatch write restores the runtime state. Configuration records replay after checkpoint restore. An owner-supplied HMAC key can attest both chain heads independently. Tokens are runtime environment values and are never returned by API responses.

Scaling route: separate independently owned portfolio processes/databases; route each portfolio's commands to one owner. Central auth, external durable event storage, off-host seals, service supervision, TLS and replicated backups belong to a production deployment. A second process must not independently mutate the same portfolio database. The current runtime does not claim distributed exactly-once actuation or high availability.
