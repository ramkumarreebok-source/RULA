"""Forward an existing authorized gateway JSON file to RULA's advisory endpoint.
This client never changes measurement timestamps or sends actuator commands.
"""
import argparse,json,os,time,urllib.request,urllib.error
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--file',required=True);p.add_argument('--server',default='http://127.0.0.1:8010');p.add_argument('--endpoint',choices=['/api/telemetry','/api/live/telemetry'],default='/api/live/telemetry');p.add_argument('--interval',type=float,default=0)
    args=p.parse_args()
    if args.interval<0:p.error('Interval must be nonnegative')
    while True:
        try:
            data=Path(args.file).read_bytes()
            if len(data)>1500000:raise ValueError('Telemetry file exceeds API size limit')
            json.loads(data)
            headers={'Content-Type':'application/json'};token=os.environ.get('RULA_CLIENT_TOKEN')
            if token:headers['Authorization']='Bearer '+token
            req=urllib.request.Request(args.server.rstrip('/')+args.endpoint,data=data,headers=headers)
            with urllib.request.urlopen(req,timeout=15) as r:print(r.read().decode(),flush=True)
        except urllib.error.HTTPError as error:print(error.read().decode(),flush=True)
        except (ValueError,OSError) as error:print('Advisory ingest failed: '+str(error),flush=True)
        if args.interval==0:break
        try:time.sleep(args.interval)
        except KeyboardInterrupt:break

if __name__=='__main__':main()
