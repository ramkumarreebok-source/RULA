"""Keyed checkpoint attestation for exported audit heads, not a blockchain consensus system."""
import hashlib,hmac,json,os

def seal(audit):
    if not audit.get('integrity'):raise ValueError('Cannot seal a failed audit integrity check')
    key=os.environ.get('RULA_AUDIT_KEY')
    if not key or len(key)<32:raise ValueError('Set RULA_AUDIT_KEY to an independent secret of at least 32 characters')
    body={k:audit[k] for k in ['head','control_head','events','control_events']}
    raw=json.dumps(body,sort_keys=True,separators=(',',':')).encode()
    return {'body':body,'hmac_sha256':hmac.new(key.encode(),raw,hashlib.sha256).hexdigest(),'method':'HMAC-SHA256; retain signed checkpoint off-host and keep key external'}

def verify(sealed):
    key=os.environ.get('RULA_AUDIT_KEY')
    if not key or len(key)<32:raise ValueError('Audit key unavailable')
    raw=json.dumps(sealed['body'],sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    expected=hmac.new(key.encode(),raw,hashlib.sha256).hexdigest()
    return {'valid':hmac.compare_digest(expected,str(sealed['hmac_sha256']))}
