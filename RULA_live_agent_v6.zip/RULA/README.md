# RULA LIVE AGENT v6

This version addresses the gap in the previous builds: its main screen is a continuous live-data agent and a real model-backed conversation. The earlier accelerated simulator is retained at `/research` and is no longer the default dashboard.

The core energy logic remains our own Python code. Conversational generation requires an actual trained model, supplied through local Ollama or an optional OpenAI API connection. Model weights are not included in this small project archive. No template router or generated toy language model is presented as a connected LLM.

## Start here on Windows

1. Extract the ZIP into a **new folder**. Open its `RULA` folder.
2. Install Ollama for Windows from https://ollama.com/download/windows. Reopen Command Prompt/launchers after installation so the new PATH is available.
3. Double-click `start_live_with_local.bat`. It downloads `llama3.2:3b` if missing, selects it and starts RULA. The model download requires internet, disk space and sufficient available memory; the published quantized model is about 2 GB on disk, which is not its full runtime RAM requirement. Speed depends on your CPU/GPU and available memory.
4. Open **http://127.0.0.1:8010**. The launcher opens it after checking the server build.
5. Verify **RULA LIVE AGENT v6** in the heading. Under **Model & live connection**, choose **Check connection**. Send **Hi**. After a successful generation, the badge reads **LLM inference verified**.

If the model is already installed, startup skips the download. The local model server must be running. To start only the automatic data/decision loop, use `start_windows.bat` or `python server.py --port 8010`; chat remains explicitly disconnected until a model is available.

The v6 build uses port 8010 to avoid confusing it with your earlier version on port 8000. If 8010 already has a server, the launcher asks you to stop that process with Ctrl+C. It never kills an unrelated process. Do not keep using an old browser tab at port 8000 and assume the code has upgraded.

## Optional OpenAI connection

Run `python start_openai.py`. Enter your API key in the concealed local terminal prompt and enter a model ID available to your account. The key is passed to the server environment and is not written to a project file. The provider/model choice is saved; credentials are not. This option uses your API account and sends chat plus requested operational evidence to the provider. No API inference or paid usage was performed in the build environment.

Connection checks distinguish provider/model access from actual inference. The app does not assume that your ChatGPT subscription supplies an API key. Use a model supporting Responses/function tools. A model-server/API error is shown as an error, without a fake conversational fallback.

## What now runs automatically

The server starts a background agent on launch. The default cycle is every 60 seconds:

**Fetch live sources → check freshness → estimate generation/forecast → plan constrained dispatch → stress test → create internal review/alert tasks → persist evidence → recover or retry.**

Public requests are cached for 10 minutes, so a 60-second decision cycle does not claim new upstream measurements every minute. The dashboard polls status every five seconds. Source observation times, cycle creation times and stale/error conditions are separate. A failing/stale source blocks new recommendations; previous results remain visibly historical.

The live store is `rula_live.sqlite`, separate from `rula.sqlite`. The loop does not advance simulation time or discharge synthetic batteries every wall-clock minute. No physical power, SOC or money is changed by a recommendation. No exchange order or equipment command is issued.

### Two explicit live modes

| Mode | Genuine inputs | Estimated/configured inputs | Authority |
|---|---|---|---|
| Weather → reference fleet (default) | Public weather and delayed satellite irradiance | Fleet generation estimates; configured load, tariffs and reference BESS | Internal tasks and recommendations |
| Fresh plant telemetry | Complete timestamped power, demand, market/tariff values, BESS SOC/health supplied by your gateway | Uncalibrated persistence forecast for future intervals | Internal tasks and recommendations |

Weather mode uses one configured public-data location, initially Chennai, for the illustrative fleet. It does not pretend that the eight reference farms are measured real plants. Solar is estimated from provider GHI and daylight/shading; wind uses a specified hub-height scaling and turbine curve. Satellite irradiance is displayed with latency and excluded from current generation when stale. These are uncalibrated asset models, not ground-truth generation.

Set latitude, longitude, load and tariffs under **Model & live connection**. To use measured readings, choose telemetry mode and upload a complete fresh JSON snapshot, or send readings continuously to `/api/live/telemetry`. It waits for authorized data rather than substituting simulation. Measurement freshness is at most 30 minutes with at most two minutes future clock skew. Weather must be at most one hour old for current recommendations.

## Genuine conversational tool agent

Chat uses the configured real model to generate text and optionally request bounded tools:

- `get_live_status`: actual runtime, source labels and recommendation evidence.
- `get_live_forecast`: dated generation estimates and their limitations.
- `get_live_tasks`: internal review/alert queue.
- `evaluate_renewable_drop`: read-only fixed-action percentage-drop stress test.
- `create_review_task`: internal task when explicitly requested by the user, owner role required.

There are at most four model turns and four tools per turn. Arguments are checked and unknown tools rejected. The model cannot approve tasks, issue trades, command equipment, fetch arbitrary URLs, run shell commands or obtain credentials. The OpenAI client uses Responses function calling; Ollama uses native chat tool calls. A local model without tool support is labeled as grounded chat without tool support.

Natural answers appear as chat messages. Tool arguments/results are optional expandable evidence, not the main response. A greeting is sent to the model normally. Chat keeps up to six user/assistant pairs per session in memory; conversational history is not retained after server restart.

Internal task acknowledgement is labeled **ACKNOWLEDGED_NO_EXTERNAL_EXECUTION**. It records review but does not act as an electricity trade or BESS dispatch. Autonomous economic execution requires actual authorized adapters and equipment/exchange control contracts, which have not been supplied.

## API additions

| Route | Method | Function |
|---|---|---|
| `/api/version` | GET | Exact build ID and serving port/process |
| `/api/live/status` | GET | Loop, sources, latest decision, tasks, errors, model status |
| `/api/live/config` | POST | Owner settings: mode, location, poll_seconds, load, tariffs, grid_limit_mw, budget_inr |
| `/api/live/cycle` | POST | Owner request to schedule a background cycle |
| `/api/live/pause`, `/api/live/resume` | POST | Persistent enable/disable of the loop |
| `/api/live/telemetry` | POST | Owner complete fresh plant/BESS snapshot |
| `/api/live/task-review` | POST | Owner `{id, approve}`; acknowledgement/rejection only |
| `/api/llm/config` | POST | Owner `{provider: "ollama" or "openai", model: "..."}`; no credential upload |
| `/api/llm/check` | POST | Check installed model/API access; does not run inference |
| `/api/llm/status` | GET | Connection and inference status |
| `/api/chat` | POST | `{text, session_id?}`; real model response and bounded tool trace |

The research APIs from v5 remain available. Optional `RULA_TOKEN` and `RULA_VIEWER_TOKEN` apply to both interfaces. Viewer cannot change live settings, review tasks or create model-requested tasks. Keep this local HTTP application on loopback unless deploying behind authenticated TLS infrastructure.

For an authorized gateway, generate a schema example with `python make_telemetry_example.py`. The generated values are explicitly synthetic. `telemetry_client.py` can submit an existing gateway file to a selected endpoint using `--endpoint /api/live/telemetry`; it never rewrites timestamps.

## Tests and delivered evidence

Run `python -m unittest discover -s tests -v`. `validation.json` records the actual delivered count and checks.

The live network smoke test exercises a real public-data cycle, constrained recommendation, task creation and evidence persistence. Model adapter/function-call tests use deterministic protocol fixtures. **Those fixtures are not real inference.** No local model or API credential was available in the build environment, so real LLM inference must be verified on your configured machine. The UI makes that distinction visible.

Browser script syntax and DOM references are checked. Rendered browser visual QA is not claimed. Legacy learned-model and research modules retain their generated-data limitations documented in `docs/RESEARCH_V5_README.md` and `docs/VALIDATION.md`.

## Sources and system boundary

- Ollama Windows: https://docs.ollama.com/windows
- Ollama chat/tools and installed model listing: https://docs.ollama.com/api/chat and https://docs.ollama.com/api/tags
- Llama 3.2 3B model metadata: https://ollama.com/library/llama3.2:3b
- OpenAI text/Responses: https://developers.openai.com/api/docs/guides/text
- OpenAI function calling: https://developers.openai.com/api/docs/guides/function-calling
- Public data: https://open-meteo.com/en/docs and https://open-meteo.com/en/docs/satellite-radiation-api

This is a live-data advisory agent plus a real model connector. It cannot be described as operational real plant control, live exchange trading or a field-validated energy AI until authorized telemetry/control connections and asset-specific validation are provided.
