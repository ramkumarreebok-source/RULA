"""Local research API. External equipment and market execution are deliberately absent."""
import argparse,json,threading,os,base64,uuid,hashlib,time,secrets,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from datetime import datetime,timezone
from core import RULA
from research import parse_receipts
from datafeeds import PublicFeeds,validate_telemetry,number,timestamp
from geospatial import motion_nowcast,demo_clouds,solar_position,site_nowcast
from healthrisk import phm,financial_risk
from vision import VisionModel
from copilot import answer
from integrity import seal,verify
from live_runtime import LiveRuntime
from llm_agent import ModelClient,ConversationalAgent

engine=RULA(os.environ.get('RULA_DATABASE','rula.sqlite'));lock=threading.RLock();feeds=PublicFeeds();feed_lock=threading.Lock();vision=VisionModel()
engine.db.execute('CREATE TABLE IF NOT EXISTS requests (key TEXT PRIMARY KEY, route TEXT, body_hash TEXT, result TEXT)');engine.db.commit()
live_database=os.environ.get('RULA_LIVE_DATABASE',str(Path(os.environ.get('RULA_DATABASE','rula.sqlite')).with_name('rula_live.sqlite')))
live=LiveRuntime(engine,feeds,lock,live_database)
model_client=ModelClient(Path(live_database).with_name('model_connection.json'))
conversation=ConversationalAgent(live,engine,lock,model_client)
idempotency={};stats={'requests':0,'errors':0,'started':time.time()}

class Handler(BaseHTTPRequestHandler):
    def reply(self,data,status=200):
        raw=json.dumps(data,allow_nan=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
    def authorized(self,write=False):
        owner=os.environ.get('RULA_TOKEN');viewer=os.environ.get('RULA_VIEWER_TOKEN');token=self.headers.get('Authorization','')
        if not owner:return True
        candidates=[owner] if write else [v for v in [owner,viewer] if v]
        return any(secrets.compare_digest(token,'Bearer '+v) for v in candidates)
    def actor(self):return 'owner-token' if os.environ.get('RULA_TOKEN') else 'local-user'
    def do_GET(self):
        stats['requests']+=1
        static={'/':'web/index.html','/research':'web/research.html','/assets/sample_clean.pgm':'samples/clean.pgm','/assets/sample_defect.pgm':'samples/defect.pgm','/assets/sample_occlusion.pgm':'samples/occlusion.pgm','/assets/sample_clouds.json':'samples/clouds.json','/assets/sample_observations.csv':'sample_observations.csv'}
        if self.path in static:
            path=Path(__file__).parent/static[self.path];raw=path.read_bytes();self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8' if self.path in ['/','/research'] else 'application/octet-stream')
            self.send_header('Cache-Control','no-store')
            if self.path not in ['/','/research']:self.send_header('Content-Disposition','attachment; filename='+path.name)
            self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw);return
        if not self.authorized():return self.reply({'error':'Enter an access token in the dashboard'},401)
        if self.path=='/api/version':return self.reply({'version':'6.0-live','dashboard':'RULA LIVE AGENT','port':self.server.server_port,'process_id':os.getpid()})
        if self.path=='/api/live/status':return self.reply({**live.status(),'model':model_client.last,'version':'6.0-live'})
        if self.path=='/api/llm/status':return self.reply(model_client.last)
        with lock:
            if self.path=='/api/state':return self.reply({'current':engine.pending or (engine.history[-1] if engine.history else engine.propose()),'analysis':engine.analysis(),'audit':engine.audit()})
            if self.path=='/api/history':return self.reply(engine.history)
            if self.path=='/api/research':return self.reply(engine.research_report())
            if self.path=='/api/feeds':return self.reply(feeds.last)
            if self.path=='/api/metrics':return self.reply({**stats,'uptime_seconds':time.time()-stats['started'],'audit_records':engine.audit()['events'],'execution_model':'single serialized state machine; no distributed worker cluster'})
            if self.path=='/api/health':return self.reply({'status':'ok','mode':'simulation','audit':engine.audit()})
        self.reply({'error':'Not found'},404)
    def do_POST(self):
        stats['requests']+=1
        origin=self.headers.get('Origin')
        if origin and origin!='http://'+self.headers.get('Host',''):return self.reply({'error':'Origin rejected'},403)
        write=self.path in ['/api/step','/api/approve','/api/scenario','/api/stop','/api/resume','/api/budget','/api/assets','/api/audit/seal','/api/live/config','/api/live/pause','/api/live/resume','/api/live/telemetry','/api/live/task-review','/api/llm/config','/api/live/cycle']
        if not self.authorized(write):return self.reply({'error':'Owner token required' if write else 'Access token required'},401)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<=size<=1500000:return self.reply({'error':'Payload too large'},413)
            payload=json.loads(self.rfile.read(size) or b'{}',parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))
            if not isinstance(payload,dict):raise ValueError('JSON object required')
            if self.path=='/api/chat':
                try:return self.reply(conversation.chat(payload.get('text',''),payload.get('session_id'),allow_task=self.authorized(True)))
                except (ValueError,TimeoutError,OSError) as error:
                    model_client.last={**model_client.last,'connected':False,'inference_verified':False,'message':str(error)[:300]}
                    return self.reply({'error':str(error),'mode':'LLM_DISCONNECTED_OR_REQUEST_FAILED','fallback_used':False},503)
            if self.path=='/api/llm/check':return self.reply(model_client.check())
            if self.path=='/api/llm/config':return self.reply(model_client.configure(payload))
            if self.path=='/api/live/config':return self.reply(live.configure(payload))
            if self.path=='/api/live/cycle':
                # Requests schedule work; UI and chat stay responsive during network waits.
                live.wake.set()
                if not live.thread or not live.thread.is_alive():live.start()
                return self.reply({'scheduled':True,'note':'Background cycle scheduled; read /api/live/status for progress'})
            if self.path in ['/api/live/pause','/api/live/resume']:
                live.stop(self.path.endswith('pause'));return self.reply({'paused':live.stopped})
            if self.path=='/api/live/telemetry':return self.reply(live.ingest(payload))
            if self.path=='/api/live/task-review':
                if not isinstance(payload.get('approve'),bool):raise ValueError('approve must be boolean')
                return self.reply(live.review_task(payload['id'],payload['approve']))
            # Network calls occur outside the engine lock; slow providers cannot stall dispatch.
            if self.path in ['/api/live/weather','/api/live/satellite']:
                lat=payload.get('latitude',13.0827);lon=payload.get('longitude',80.2707)
                with feed_lock:
                    result=feeds.weather(lat,lon) if self.path.endswith('weather') else feeds.satellite(lat,lon)
                return self.reply(result)
            with lock:
                key=self.headers.get('Idempotency-Key');body_hash=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
                if write and key:
                    if len(key)>128:raise ValueError('Idempotency key too long')
                    saved_row=engine.db.execute('SELECT route,body_hash,result FROM requests WHERE key=?',(key,)).fetchone()
                    if saved_row:
                        if saved_row[0]!=self.path or saved_row[1]!=body_hash:return self.reply({'error':'Idempotency key reused for a different request'},409)
                        return self.reply(json.loads(saved_row[2]))
                    if key in idempotency:
                        saved=idempotency[key]
                        if saved['path']!=self.path or saved['body_hash']!=body_hash:return self.reply({'error':'Idempotency key reused for a different request'},409)
                        return self.reply(saved['result'])
                request_meta={'key':key,'route':self.path,'body_hash':body_hash} if write and key else None
                if self.path=='/api/step':result=engine.execute(request_meta=request_meta)
                elif self.path=='/api/approve':
                    if engine.pending is None or engine.pending['decision']['id']!=payload.get('decision_id'):raise ValueError('Exact current pending decision_id required')
                    engine.control('approval',{'actor':self.actor(),'decision_id':payload['decision_id']});result=engine.execute(True,request_meta=request_meta)
                elif self.path=='/api/scenario':
                    if payload.get('name') not in ['normal','storm','price_spike','grid_outage']:raise ValueError('Unknown scenario')
                    engine.shock=payload['name'];engine.pending=None;engine.control('scenario',{'actor':self.actor(),'name':engine.shock});result=engine.propose()
                elif self.path in ['/api/stop','/api/resume']:
                    engine.emergency_stop=self.path.endswith('stop');engine.pending=None
                    engine.control('emergency_stop',{'actor':self.actor(),'active':engine.emergency_stop});result={'emergency_stop':engine.emergency_stop}
                elif self.path=='/api/budget':
                    budget=number(payload['budget_inr'],engine.spent,1e12,'budget');engine.budget=budget;engine.pending=None
                    engine.control('budget',{'actor':self.actor(),'budget_inr':budget});result={'budget_inr':budget}
                elif self.path=='/api/assets':
                    result=self.asset_update(payload)
                elif self.path=='/api/ask':result=answer(engine,payload.get('text',''))
                elif self.path=='/api/import':
                    rows=parse_receipts(str(payload.get('csv','')));engine.imported=rows
                    intervals={}
                    for r in rows:intervals[r['timestamp']]=intervals.get(r['timestamp'],0)+r['output_mw']
                    result={'validated_rows':len(rows),'mode':'OBSERVATION_ANALYSIS_ONLY','interval_generation_mw':intervals,'note':'Each interval totals only the assets present in the CSV; dispatch requires a complete fresh telemetry snapshot.'}
                elif self.path=='/api/satellite/nowcast':
                    data=demo_clouds() if payload.get('demo') else payload
                    result=motion_nowcast(**{k:data[k] for k in ['previous','current','interval_minutes','pixel_km','horizon_minutes']});result['source']='SYNTHETIC_DEMO' if payload.get('demo') else 'USER_SUPPLIED_CLOUD_FRACTION_RASTERS'
                    if payload.get('demo'):
                        result['site_warning']=site_nowcast(data,result,engine.assets,engine.time,{'south':10.5,'north':12.5,'west':76,'east':79})
                    elif payload.get('bounds'):
                        result['site_warning']=site_nowcast(data,result,engine.assets,timestamp(payload['observation_time']),payload['bounds'])
                elif self.path=='/api/vision':
                    encoded=str(payload.get('base64',''))
                    if len(encoded)>1400000:raise ValueError('Encoded image too large')
                    result=vision.inspect(base64.b64decode(encoded,validate=True))
                elif self.path=='/api/phm':result=phm(str(payload['asset_id'])[:100],payload['observations'],number(payload.get('threshold',.8),0,1,'threshold'))
                elif self.path=='/api/telemetry':result=self.telemetry_advisory(payload)
                elif self.path=='/api/live/advisory':result=self.weather_advisory()
                elif self.path=='/api/audit/seal':result=seal(engine.audit())
                elif self.path=='/api/audit/verify-seal':result=verify(payload)
                else:return self.reply({'error':'Not found'},404)
                if write and key:
                    idempotency[key]={'path':self.path,'body_hash':body_hash,'result':json.loads(json.dumps(result))}
                    if len(idempotency)>1000:del idempotency[next(iter(idempotency))]
                    engine.db.execute('INSERT OR IGNORE INTO requests(key,route,body_hash,result) VALUES(?,?,?,?)',(key,self.path,body_hash,json.dumps(result,sort_keys=True,allow_nan=False)));engine.db.commit()
                self.reply(result)
        except (ValueError,TypeError,KeyError,IndexError,OverflowError,RecursionError) as e:
            stats['errors']+=1;self.reply({'error':str(e)},400)
        except (urllib.error.URLError,TimeoutError,OSError) as e:
            stats['errors']+=1;self.reply({'error':'External data unavailable. Check internet access and provider availability. No simulated substitute was returned.','detail':type(e).__name__},502)
    def asset_update(self,payload):
        supplied=payload['assets'];current={a['id']:a for a in engine.assets}
        if not isinstance(supplied,list) or len(supplied)!=len(current):raise ValueError('Complete eight-asset configuration required')
        updated=[];seen=set()
        for entry in supplied:
            identity=entry['id']
            if identity not in current or identity in seen:raise ValueError('Unknown or duplicate configured asset')
            seen.add(identity);old=current[identity]
            updated.append({**old,'capacity_mw':number(entry['capacity_mw'],.01,500,'capacity'),
                            'latitude':number(entry['latitude'],-90,90,'latitude'),'longitude':number(entry['longitude'],-180,180,'longitude'),
                            'elevation_m':number(entry.get('elevation_m',0),-500,9000,'elevation'),'horizon_deg':number(entry.get('horizon_deg',0),0,90,'horizon'),
                            'coordinates_source':'USER_CONFIGURED'})
        engine.assets=updated;engine.pending=None;engine.control('asset_configuration',{'actor':self.actor(),'assets':updated})
        engine.propose()
        return {'assets':updated,'note':'Coordinates affect geometry; elevation is recorded, not a wind-flow or terrain model.'}
    def telemetry_advisory(self,payload):
        state=validate_telemetry(payload,engine.assets);batteries=payload['batteries'];existing={b['id']:b for b in engine.batteries}
        if not isinstance(batteries,list) or len(batteries)!=2:raise ValueError('Two fresh BESS observations required')
        replacement=[];seen=set()
        for entry in batteries:
            identity=entry['id']
            if identity not in existing or identity in seen:raise ValueError('Invalid BESS IDs')
            seen.add(identity);old=existing[identity]
            replacement.append({**old,'soc':number(entry['soc_mwh'],.1*old['capacity'],.9*old['capacity'],'SOC'),'health':number(entry['health'],.5,1,'BESS health')})
        original=engine.batteries
        try:
            engine.batteries=replacement;decision=engine.optimize(state)
            return {'state':state,'decision':decision,'risk':financial_risk(state,decision['selected']) if 'selected' in decision else None,
                    'mode':'ADVISORY_ONLY','execution':'No SCADA command or market order is issued. One-step dispatch uses configured BESS capacity/power and remaining research budget.'}
        finally:engine.batteries=original
    def weather_advisory(self):
        w=feeds.last.get('weather')
        if not w:raise ValueError('Refresh live weather first')
        now=datetime.now(timezone.utc);age=(now-timestamp(w['observation_time'])).total_seconds()
        if age>3600 or age<-120:raise ValueError('Weather is stale or future-dated; refresh data')
        generated=[]
        for step in w['hourly']:
            if timestamp(step['time'])<now:continue
            solar=0.;wind=0.
            for a in engine.assets:
                if a['kind']=='solar':solar+=a['capacity_mw']*min(1,step['ghi_w_m2']/1000)*a['health']
                else:
                    v=step['wind_10m_ms']*(100/10)**.14
                    wind+=a['capacity_mw']*(0 if v>=25 else min(1,max(0,(v**3-27)/(1728-27))))*a['health']
            generated.append({'time':step['time'],'solar_estimate_mw':solar,'wind_estimate_mw':wind})
        satellite=feeds.last.get('satellite')
        return {'mode':'LIVE_WEATHER_SYNTHETIC_PORTFOLIO_ADVISORY','forecast':generated[:24],'weather_age_seconds':age,
                'satellite_latest':satellite.get('latest') if satellite else None,
                'assumptions':'One fetched location applied to illustrative fleet; fixed 0.14 wind-shear exponent to 100 m, GHI/1000 solar scaling; no site calibration. Satellite observation shown separately, not substituted into forecasts.',
                'execution':'Does not alter simulator, submit trades or control equipment.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8010);parser.add_argument('--host',default='127.0.0.1');args=parser.parse_args()
    print(f'RULA LIVE AGENT v6: http://127.0.0.1:{args.port}',flush=True)
    http=ThreadingHTTPServer((args.host,args.port),Handler);live.start()
    threading.Thread(target=model_client.check,name='rula-model-check',daemon=True).start()
    try:http.serve_forever()
    except KeyboardInterrupt:pass
    finally:http.server_close();live.close();engine.db.close()
