"""Own-code small neural research models; generated training data only."""
import math,random

def sigmoid(x):return 1/(1+math.exp(-max(-30,min(30,x))))

class TinyMLP:
    def __init__(self,seed=31):
        rng=random.Random(seed);self.input=[[rng.uniform(-.4,.4) for _ in range(4)] for _ in range(8)]
        self.output=[rng.uniform(-.4,.4) for _ in range(9)]
        def example():
            sun=rng.random();cloud=rng.random();wind=rng.uniform(0,30)
            solar=40*sun*(1-cloud);power=0 if wind>=25 else min(1,max(0,(wind**3-27)/(1728-27)))
            return [sun,cloud,wind/30],(solar+30*power)/70
        data=[example() for _ in range(600)]
        for _ in range(30):
            for x,y in data:self.update(x,y,.04)
        holdout=[example() for _ in range(150)]
        self.mae_mw=sum(abs(self.predict(x)-y)*70 for x,y in holdout)/len(holdout)
    def forward(self,x):
        x=[1.]+x;h=[math.tanh(sum(a*b for a,b in zip(row,x))) for row in self.input]
        y=sigmoid(sum(a*b for a,b in zip(self.output,[1.]+h)));return x,h,y
    def predict(self,x):return self.forward(x)[2]
    def update(self,x,target,rate):
        x,h,p=self.forward(x);delta=(p-target)*p*(1-p);old=list(self.output)
        for j,v in enumerate([1.]+h):self.output[j]-=rate*delta*v
        for i,row in enumerate(self.input):
            hidden_delta=delta*old[i+1]*(1-h[i]**2)
            for j,v in enumerate(x):row[j]-=rate*hidden_delta*v
    def report(self,state):
        solar=[a for a in state['assets'] if a['kind']=='solar']
        sun=sum(a['solar_position']['cos_zenith'] for a in solar)/len(solar) if solar else 0.
        return {'generation_estimate_reference_fleet_mw':70*self.predict([sun,state['cloud_fraction'],state['wind_ms']/30]),
                'reference_capacity_mw':70,'architecture':'3 inputs → 8 tanh hidden units → 1 sigmoid output; own backpropagation',
                'training_samples':600,'heldout_synthetic_samples':150,'heldout_synthetic_mae_mw':self.mae_mw,
                'training_source':'generated 40 MW solar + 30 MW wind physics profiles','authority':'benchmark only; no real-data validation or dispatch authority'}

class GraphHead:
    def __init__(self):
        self.weights=[0.]*4;rng=random.Random(92)
        def example():
            own=rng.random();neighbor=rng.random();message=.7*own+.3*neighbor
            label=int(.6*own+.4*neighbor>.55)
            return [1,own,neighbor,message],label
        train=[example() for _ in range(360)]
        for _ in range(30):
            for x,y in train:
                p=sigmoid(sum(w*v for w,v in zip(self.weights,x)))
                for i,v in enumerate(x):self.weights[i]+=.1*(y-p)*v
        holdout=[example() for _ in range(120)];self.accuracy=sum((sigmoid(sum(w*v for w,v in zip(self.weights,x)))>.5)==y for x,y in holdout)/120
    def infer(self,initial,messages,nodes):
        result={}
        for node,own in initial.items():
            neighbors=[n for n in nodes if n!='BUS'] if node=='BUS' else ['BUS']
            neighbor=sum(initial[n] for n in neighbors)/len(neighbors)
            result[node]=sigmoid(sum(w*v for w,v in zip(self.weights,[1,own,neighbor,messages[node]])))
        return result

graph_head=GraphHead()
