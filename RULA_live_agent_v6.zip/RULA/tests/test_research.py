import unittest,sys,os,math
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import RULA
from research import OnlineRegressor,parse_receipts,control_chart

class TestResearch(unittest.TestCase):
    def test_learning(self):
        m=OnlineRegressor(2,.5)
        for _ in range(100): m.update([1.,.5],3.)
        self.assertLess(abs(m.predict([1.,.5])-3),.01)
    def test_plan_does_not_mutate(self):
        e=RULA(':memory:'); before=[b['soc'] for b in e.batteries]; spent=e.spent
        plan=e.plan(e.sense()); self.assertEqual(plan['status'],'PLANNED')
        self.assertEqual(len(plan['actions']),8); self.assertEqual(before,[b['soc'] for b in e.batteries]); self.assertEqual(spent,e.spent)
        self.assertTrue(all(a['feasible'] for a in plan['actions']))
    def test_forecast_is_scored_after_observation(self):
        e=RULA(':memory:'); e.execute(True); self.assertEqual(len(e.forecast_errors),0)
        e.execute(True); self.assertEqual(len(e.forecast_errors),1)
    def test_import_contract(self):
        text='timestamp,asset_id,output_mw,capacity_mw,latitude,longitude\n2026-10-03T00:00:00Z,S1,2,5,11,77\n'
        self.assertEqual(len(parse_receipts(text)),1)
        for bad in [text.replace(',2,5,',',nan,5,'),text.replace(',2,5,',',6,5,'),text+text.splitlines()[1]+'\n',text.replace('00:00:00Z','00:00:00')]:
            with self.assertRaises(ValueError): parse_receipts(bad)
    def test_chart(self):
        self.assertEqual(control_chart([1]*24)['status'],'INSUFFICIENT_BASELINE')
        self.assertTrue(control_chart([1]*25+[10])['outside_limits'])

if __name__=='__main__': unittest.main()
