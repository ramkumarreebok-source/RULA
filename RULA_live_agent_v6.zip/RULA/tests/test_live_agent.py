import unittest,sys,os,tempfile,threading,copy,json
import time
from datetime import datetime,timezone,timedelta
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import RULA
from live_runtime import LiveRuntime
from llm_agent import ModelClient,ConversationalAgent

class FixtureFeeds:
    def weather(self,lat,lon):
        now=datetime.now(timezone.utc)
        return {'source':'TEST_FIXTURE_NOT_LIVE','observation_time':now.isoformat(),'cloud_fraction':.4,'wind_10m_ms':6,
                'hourly':[{'time':(now+timedelta(hours=i)).isoformat(),'cloud_fraction':.4,'wind_10m_ms':6,'ghi_w_m2':650.} for i in range(25)]}
    def satellite(self,lat,lon):return {'latest':{'time':(datetime.now(timezone.utc)-timedelta(hours=2)).isoformat(),'ghi_w_m2':500},'age_seconds':7200,'stale_for_30min_control':True}

class TestLiveAgent(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.engine=RULA(':memory:');self.lock=threading.RLock();self.live=LiveRuntime(self.engine,FixtureFeeds(),self.lock,self.temp.name+'/live.sqlite')
    def tearDown(self):self.live.close();self.engine.db.close();self.temp.cleanup()
    def test_live_cycle_no_accelerated_simulation(self):
        old=self.engine.time;spent=self.engine.spent;r=self.live.cycle()
        self.assertEqual(r['state']['source'],'LIVE_WEATHER_ESTIMATED_REFERENCE_FLEET');self.assertEqual(self.engine.time,old);self.assertEqual(self.engine.spent,spent)
        self.assertEqual(r['state']['sources']['prices'],'USER_CONFIGURED_TARIFF_NOT_LIVE_MARKET');self.assertEqual(len(r['forecast']),24)
        self.assertEqual(self.live.audit()['cycles'],1);self.assertGreaterEqual(len(self.live.tasks),1)
    def test_forecast_preserves_observation_timestamp(self):
        w=FixtureFeeds().weather(13,80);future=datetime.now(timezone.utc)+timedelta(hours=3)
        s=self.live.weather_state(future,w,self.live.settings,self.engine.assets,False)
        self.assertEqual(s['weather_observation_time'],w['observation_time'])
    def test_stale_source_blocks_and_keeps_historical(self):
        self.live.cycle();old=self.live.latest['id'];f=FixtureFeeds()
        def stale(lat,lon):
            w=f.weather(lat,lon);w['observation_time']=(datetime.now(timezone.utc)-timedelta(hours=2)).isoformat();return w
        self.live.feeds.weather=stale
        with self.assertRaises(ValueError):self.live.cycle()
        self.assertEqual(self.live.latest['id'],old);self.assertFalse(self.live.status()['fresh'])
    def test_telemetry_mode_waits_for_real_input(self):
        self.live.configure({'mode':'telemetry'})
        with self.assertRaises(ValueError):self.live.cycle()
    def test_task_acknowledgement_never_executes(self):
        task=self.live.create_task('REVIEW','Review tomorrow reserve')
        result=self.live.review_task(task['id'],True);self.assertEqual(result['status'],'ACKNOWLEDGED_NO_EXTERNAL_EXECUTION');self.assertFalse(result['external_execution'])
    def test_stop_prevents_cycle(self):
        self.live.stop(True);self.assertEqual(self.live.cycle()['status'],'PAUSED')
    def test_background_loop_runs_without_button(self):
        self.live.start();deadline=time.monotonic()+3
        while self.live.latest is None and time.monotonic()<deadline:time.sleep(.02)
        self.assertIsNotNone(self.live.latest);self.assertTrue(self.live.status()['loop_active'])
    def test_ollama_protocol_and_real_tool_roundtrip_fixture(self):
        self.live.cycle();client=ModelClient();client.provider='ollama';client.model='fixture-model';client.last={'connected':True,'tools_supported':True}
        calls=[]
        def http(url,payload=None,headers=None,timeout=90):
            calls.append(payload)
            if len(calls)==1:return {'message':{'role':'assistant','content':'','tool_calls':[{'function':{'name':'get_live_status','arguments':{}}}]}}
            self.assertEqual(payload['messages'][-1]['role'],'tool')
            return {'message':{'role':'assistant','content':'The weather-based generation is estimated. No real trades were executed.'}}
        client.http=http;agent=ConversationalAgent(self.live,self.engine,self.lock,client)
        result=agent.chat('What is happening now?');self.assertEqual(len(calls),2);self.assertEqual(result['tool_trace'][0]['tool'],'get_live_status');self.assertTrue(result['inference_verified'])
        # This is a protocol fixture, not a real model inference claim in delivery validation.
    def test_disconnected_llm_no_template_fallback(self):
        client=ModelClient();client.provider='ollama'
        def fail(*args,**kwargs):raise ValueError('Model unavailable')
        client.http=fail
        with self.assertRaises(ValueError):ConversationalAgent(self.live,self.engine,self.lock,client).chat('Hi')
    def test_tool_authority_and_parameter_validation(self):
        agent=ConversationalAgent(self.live,self.engine,self.lock)
        with self.assertRaises(ValueError):agent.call_tool('execute_trade',{},'Hi')
        with self.assertRaises(ValueError):agent.call_tool('get_live_status',{'extra':1},'Hi')
        with self.assertRaises(ValueError):agent.call_tool('create_review_task',{'summary':'Do something'},'Hi')
        task=agent.call_tool('create_review_task',{'summary':'Review storage reserve'},'Create a review task');self.assertFalse(task['external_execution'])
    def test_openai_response_tool_protocol_fixture(self):
        self.live.cycle();client=ModelClient();client.provider='openai';client.model='fixture-model';old=os.environ.get('OPENAI_API_KEY');os.environ['OPENAI_API_KEY']='fixture-not-a-real-key';calls=[]
        def http(url,payload=None,headers=None,timeout=90):
            calls.append(payload)
            if len(calls)==1:return {'output':[{'type':'function_call','id':'fc1','call_id':'c1','name':'get_live_forecast','arguments':'{}'}]}
            self.assertTrue(any(i.get('type')=='function_call_output' for i in payload['input']))
            self.assertFalse(payload['store'])
            return {'output':[{'type':'message','role':'assistant','content':[{'type':'output_text','text':'Here is the forecast, based on estimated generation.'}]}]}
        client.http=http
        try:
            result=ConversationalAgent(self.live,self.engine,self.lock,client).chat('Explain the forecast');self.assertEqual(len(calls),2);self.assertIn('forecast',result['answer'])
        finally:
            if old is None:os.environ.pop('OPENAI_API_KEY',None)
            else:os.environ['OPENAI_API_KEY']=old

if __name__=='__main__':unittest.main()
