import unittest, tempfile, os, sys
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import RULA, DT, ETA

class TestRULA(unittest.TestCase):
    def setUp(self): self.e=RULA(':memory:')
    def test_energy_units_and_efficiency(self):
        s=self.e.sense(); a=self.e.evaluate(s,[4.,0.])
        self.assertAlmostEqual(a['soc_after_mwh'][0],10-4*DT/ETA)
        self.assertAlmostEqual(a['purchase_inr'],a['import_mw']*DT*1000*s['buy_inr_kwh'])
    def test_96_intervals_preserve_constraints(self):
        self.e.budget=1e9
        for _ in range(96):
            x=self.e.execute(True); self.assertEqual(x['decision']['status'],'EXECUTED_SIMULATION')
            self.assertAlmostEqual(x['verification']['balance_error_mw'],0,places=8)
            for b in self.e.batteries: self.assertTrue(2-1e-8<=b['soc']<=18+1e-8)
        self.assertTrue(self.e.audit()['integrity'])
    def test_approval_before_execution(self):
        self.e.shock='storm'; before=[b['soc'] for b in self.e.batteries]
        self.assertEqual(self.e.execute()['decision']['status'],'AWAITING_APPROVAL')
        self.assertEqual(before,[b['soc'] for b in self.e.batteries]); self.assertEqual(self.e.audit()['events'],0)
        self.e.execute(True); self.assertEqual(self.e.audit()['events'],1)
    def test_budget_blocks(self):
        self.e.budget=0; self.e.shock='storm'; self.assertEqual(self.e.execute()['decision']['status'],'BLOCKED'); self.assertEqual(self.e.spent,0)
    def test_tamper_detection(self):
        self.e.execute(True); self.e.db.execute("UPDATE audit SET payload='{}'"); self.assertFalse(self.e.audit()['integrity'])
    def test_restart_checkpoint(self):
        with tempfile.TemporaryDirectory() as d:
            path=os.path.join(d,'audit.sqlite'); a=RULA(path); a.execute(True); a.db.close()
            b=RULA(path); self.assertGreater(b.spent,0); self.assertEqual(b.audit()['events'],1); b.db.close()
    def test_grid_outage(self):
        self.e.shock='grid_outage'; x=self.e.propose(); self.assertLessEqual(x['decision']['selected']['import_mw'],8.)

if __name__=='__main__': unittest.main()
