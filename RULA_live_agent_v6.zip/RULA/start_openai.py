"""Optional API-key launcher: input is concealed and remains in process environment only."""
import os,sys,getpass,subprocess
from pathlib import Path
key=os.environ.get('OPENAI_API_KEY') or getpass.getpass('OpenAI API key (hidden; not saved): ')
model=os.environ.get('RULA_LLM_MODEL') or input('Model ID available to your API account: ').strip()
if not key or not model:sys.exit('API key and model ID are required')
env={**os.environ,'OPENAI_API_KEY':key,'RULA_LLM_PROVIDER':'openai','RULA_LLM_MODEL':model}
root=Path(__file__).resolve().parent
# Explicit launcher configuration overrides any previous local-only connection file, without storing a key.
(root/'model_connection.json').write_text(__import__('json').dumps({'provider':'openai','model':model}))
subprocess.run([sys.executable,str(root/'launch_live.py')],cwd=root,env=env)
