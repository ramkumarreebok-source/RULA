@echo off
cd /d "%~dp0"
if not exist server.py (
 echo Extract the ZIP and open its RULA folder first.
 pause
 exit /b 1
)
python --version >nul 2>&1
if errorlevel 1 (
 echo Python was not found. Install Python and select Add Python to PATH.
 pause
 exit /b 1
)
python launch_live.py
pause
