"""RULA: dependency-free, unit-consistent renewable utility research engine."""
import math, random, json, hashlib, sqlite3, uuid, time as walltime
from datetime import datetime, timedelta, timezone
from research import OnlineRegressor, features, control_chart
from geospatial import solar_position,terrain_shading,motion_nowcast,demo_clouds
from healthrisk import financial_risk,network_report,phm,bayesian_rate
from quantum_research import benchmark
from neural import TinyMLP

DT = .25  # hours; all power MW, energy MWh, currency INR, price INR/kWh
ETA = .95

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

class RULA:
    def __init__(self, database='rula.sqlite', seed=42):
        self.db = sqlite3.connect(database, check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS audit (seq INTEGER PRIMARY KEY, previous TEXT, payload TEXT, hash TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS controls (seq INTEGER PRIMARY KEY, previous TEXT, payload TEXT, hash TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS requests (key TEXT PRIMARY KEY, route TEXT, body_hash TEXT, result TEXT)')
        self.db.execute('PRAGMA journal_mode=WAL')
        if not self.audit()['integrity']:raise ValueError('Audit integrity failed; refusing startup')
        self.rng = random.Random(seed)
        self.time = datetime(2026, 10, 3, 6, tzinfo=timezone.utc)
        self.batteries = [{'id':f'BESS-{i+1}', 'capacity':20., 'soc':10., 'power':5., 'health':1.} for i in range(2)]
        self.budget = 2000000.; self.spent = 0.; self.revenue = 0.
        self.history = []; self.pending = None; self.shock = 'normal'
        self.learner=OnlineRegressor(); self.imported=[]; self.latest_forecast=None; self.forecast_errors=[]
        self.emergency_stop=False; self.health_observations={}; self.pending_created=None; self.last_research=None
        self.neural_model=TinyMLP()
        self.assets = [{'id':f'{kind.upper()}-{i+1}', 'kind':kind, 'capacity_mw':cap,
                        'latitude':11.0+i*.3, 'longitude':77.0+i*.2, 'elevation_m':150+i*40,
                        'health':1., 'coordinates_source':'synthetic'}
                       for kind,n,cap in [('solar',5,8.),('wind',3,10.)] for i in range(n)]
        row = self.db.execute('SELECT payload FROM audit ORDER BY seq DESC LIMIT 1').fetchone()
        if row:
            saved = json.loads(row[0])['checkpoint']
            self.time = datetime.fromisoformat(saved['time']); self.batteries = saved['batteries']
            self.spent = saved['spent']; self.revenue = saved['revenue']; self.assets = saved['assets']
            learned=saved.get('learning')
            if learned:
                self.learner.weights=learned['weights']; self.learner.samples=learned['samples']; self.learner.errors=learned['errors']
            self.latest_forecast=saved.get('latest_forecast'); self.forecast_errors=saved.get('forecast_errors',[])
            self.health_observations=saved.get('health_observations',{})
            self.budget=saved.get('budget',self.budget);self.emergency_stop=saved.get('emergency_stop',False)
        self.history=[json.loads(r[0]) for r in self.db.execute('SELECT payload FROM audit ORDER BY seq DESC LIMIT 192')][::-1]
        # Replay persistent configuration controls, including emergency stop set after the last dispatch.
        for record in self.db.execute('SELECT payload FROM controls ORDER BY seq'):
            event=json.loads(record[0]);detail=event['detail']
            if event['event']=='emergency_stop':self.emergency_stop=detail['active']
            elif event['event']=='budget':self.budget=detail['budget_inr']
            elif event['event']=='asset_configuration':self.assets=detail['assets']

    def sense(self, time=None, noise=True):
        t = time or self.time; hour = (t.hour+5.5+t.minute/60)%24
        cloud = .85 if self.shock=='storm' else .25+.15*math.sin(hour)
        wind = 28. if self.shock=='storm' else 8.+2*math.sin(hour/3)
        assets = []
        for a in self.assets:
            position=solar_position(t,a['latitude'],a['longitude'])
            sunlight=position['cos_zenith']*terrain_shading(position['elevation_deg'],a.get('horizon_deg',0.))
            factor = sunlight*(1-cloud) if a['kind']=='solar' else (0 if wind>=25 else min(1,max(0,(wind**3-3**3)/(12**3-3**3))))
            power = a['capacity_mw']*factor*a['health']
            if noise: power *= self.rng.uniform(.94,1.06)
            assets.append({**a, 'output_mw':min(a['capacity_mw'],power),'solar_position':position})
        return {'time':t.isoformat(), 'source':'SIMULATED', 'assets':assets,
                'solar_mw':sum(a['output_mw'] for a in assets if a['kind']=='solar'),
                'wind_mw':sum(a['output_mw'] for a in assets if a['kind']=='wind'),
                'demand_mw':26+5*math.sin(hour/4), 'buy_inr_kwh':18. if self.shock=='price_spike' else 5+3*(17<=hour<=22),
                'sell_inr_kwh':4.5+2*(17<=hour<=22), 'grid_limit_mw':8. if self.shock=='grid_outage' else 30.,
                'cloud_fraction':cloud, 'wind_ms':wind, 'carbon_kg_kwh':.7}

    def forecast(self):
        # Physics/time-of-day baseline with online residual correction. Bounds are heuristic, not calibrated confidence.
        capacity=sum(a['capacity_mw'] for a in self.assets)
        residuals = [h['state']['solar_mw']+h['state']['wind_mw']-h['baseline_mw'] for h in self.history[-24:]]
        bias = sum(residuals)/len(residuals) if residuals else 0.
        sigma = math.sqrt(sum((r-bias)**2 for r in residuals)/max(1,len(residuals))) if residuals else 3.
        result=[]
        for k in range(1,25):
            s=self.sense(self.time+timedelta(minutes=15*k),False)
            mean=max(0,min(capacity,s['solar_mw']+s['wind_mw']+self.learner.predict(features(s)))); width=1.96*max(3.,sigma)*math.sqrt(k)
            result.append({'time':s['time'],'renewable_mw':mean,'lower_mw':max(0,mean-width),'upper_mw':min(capacity,mean+width),
                           'demand_mw':s['demand_mw'],'buy_inr_kwh':s['buy_inr_kwh']})
        return {'method':'physics baseline + own online linear residual model', 'interval_type':'heuristic uncertainty envelope', 'steps':result}

    def plan(self,state,horizon=8,width=12):
        """Approximate receding horizon beam search; first action is executed only."""
        original=self.batteries; spent=self.spent
        beam=[(0.,[],[dict(b) for b in original],spent)]
        try:
            for step in range(horizon):
                s=state if step==0 else self.sense(self.time+timedelta(minutes=15*step),False)
                if step>0:
                    correction=self.learner.predict(features(s));base=s['solar_mw']+s['wind_mw']
                    corrected=max(0,min(sum(a['capacity_mw'] for a in self.assets),base+correction))
                    if base>0:
                        s={**s,'solar_mw':s['solar_mw']*corrected/base,'wind_mw':s['wind_mw']*corrected/base}
                expanded=[]
                for score,path,batteries,path_spent in beam:
                    self.batteries=batteries; self.spent=path_spent
                    options=self.optimize(s)
                    for a in options['alternatives']:
                        next_b=[{**b,'soc':soc} for b,soc in zip(batteries,a['soc_after_mwh'])]
                        expanded.append((score+a['score'],path+[a],next_b,path_spent+a['purchase_inr']+a['degradation_inr']))
                if not expanded: return {'status':'INFEASIBLE_HORIZON','steps_completed':step,'actions':[]}
                beam=sorted(expanded,key=lambda x:x[0])[:width]
            score,actions,_,_=beam[0]
            return {'status':'PLANNED','horizon_hours':horizon*DT,'objective':score,'actions':actions,
                    'method':'approximate deterministic beam search; no global optimality guarantee'}
        finally: self.batteries=original; self.spent=spent

    def evaluate(self,s,powers):
        """Positive battery power discharges. Negative power charges."""
        renewable=s['solar_mw']+s['wind_mw']; battery=sum(powers)
        net=s['demand_mw']-renewable-battery
        imported=min(max(0,net),s['grid_limit_mw']); exported=min(max(0,-net),s['grid_limit_mw'])
        unserved=max(0,net-imported); curtailed=max(0,-net-exported)
        purchase=imported*DT*1000*s['buy_inr_kwh']; revenue=exported*DT*1000*s['sell_inr_kwh']
        degradation=sum(abs(p)*DT*1000*.3/max(b['health'],.5) for p,b in zip(powers,self.batteries))
        carbon=imported*DT*1000*s['carbon_kg_kwh']
        feasible=purchase+degradation<=self.budget-self.spent+1e-7
        soc=[]
        for p,b in zip(powers,self.batteries):
            new=b['soc']-(p*DT/ETA if p>=0 else p*DT*ETA); soc.append(new)
            feasible &= abs(p)<=b['power']+1e-9 and .1*b['capacity']-1e-9<=new<=.9*b['capacity']+1e-9
        # Reserve deficit penalizes depleted storage against forecast uncertainty.
        reserve_penalty=sum(max(0,.3*b['capacity']-v)*150 for b,v in zip(self.batteries,soc))
        score=purchase-revenue+degradation+carbon*.05+unserved*DT*1000000+reserve_penalty
        return {'battery_mw':list(powers),'soc_after_mwh':soc,'import_mw':imported,'export_mw':exported,
                'unserved_mw':unserved,'curtailment_mw':curtailed,'purchase_inr':purchase,'revenue_inr':revenue,
                'degradation_inr':degradation,'carbon_kg':carbon,'score':score,'feasible':bool(feasible)}

    def optimize(self,s):
        choices=[]
        for b in self.batteries:
            low=-min(b['power'],max(0,(.9*b['capacity']-b['soc'])/(DT*ETA)))
            high=min(b['power'],max(0,(b['soc']-.1*b['capacity'])*ETA/DT))
            choices.append(sorted(set([low,low/2,0.,high/2,high])))
        candidates=[self.evaluate(s,[a,b]) for a in choices[0] for b in choices[1]]
        valid=sorted((c for c in candidates if c['feasible']),key=lambda c:c['score'])
        if not valid:
            return {'status':'BLOCKED','reason':'No dispatch satisfies SOC and remaining gross spending budget.', 'alternatives':[]}
        best=valid[0]
        stressed={**s,'solar_mw':s['solar_mw']*.7,'wind_mw':s['wind_mw']*.7}
        return {'status':'PROPOSED','selected':best,'alternatives':valid[:5],
                'counterfactual_renewable_drop_30pct':self.evaluate(stressed,best['battery_mw']),
                'requires_approval':best['purchase_inr']>40000 or best['unserved_mw']>1e-6 or self.shock=='storm',
                'reason':'Minimum enumerated cost, carbon, degradation, reserve and unmet-demand objective within grid, SOC, power and budget limits.',
                'search':'25-point discrete dispatch enumeration; not a global continuous or horizon optimum'}

    def propose(self):
        s=self.sense(); d=self.optimize(s); plan=self.plan(s)
        if plan['status']=='PLANNED':
            d['selected']=plan['actions'][0]; best=d['selected']
            d['requires_approval']=best['purchase_inr']>40000 or best['unserved_mw']>1e-6 or self.shock=='storm'
            d['counterfactual_renewable_drop_30pct']=self.evaluate({**s,'solar_mw':s['solar_mw']*.7,'wind_mw':s['wind_mw']*.7},best['battery_mw'])
            d['reason']='First dispatch of minimum retained two-hour beam-search path within battery, grid and gross budget limits.'
            d['search']=plan['method']
        d['plan']=plan
        d['id']=uuid.uuid4().hex
        self.pending={'state':s,'decision':d,'forecast':self.forecast(), 'baseline_mw':sum(self.sense(noise=False)[k] for k in ['solar_mw','wind_mw'])}
        self.pending_created=walltime.monotonic()
        self.last_research=self.research_report(self.pending)
        if self.last_research.get('financial_risk',{}).get('shortage_frequency',0)>.2:
            d['requires_approval']=True
            d['risk_approval_reason']='Illustrative Monte Carlo shortage frequency exceeds 20%'
        self.control('proposal',{'decision_id':d['id'],'status':d['status']})
        return self.pending

    def execute(self, approved=False,request_meta=None):
        if self.emergency_stop:raise ValueError('Emergency stop active. Resume explicitly before simulation execution.')
        if self.pending is None: self.propose()
        out=self.pending; d=out['decision']
        if self.pending_created is not None and walltime.monotonic()-self.pending_created>300:
            self.pending=None; raise ValueError('Proposal expired after five minutes; refresh the proposal before approving')
        if d['status']=='BLOCKED': return out
        if d['requires_approval'] and not approved:
            d['status']='AWAITING_APPROVAL'; return out
        a=d['selected']
        if not self.evaluate(out['state'],a['battery_mw'])['feasible']: raise ValueError('Dispatch failed revalidation')
        if not self.audit()['integrity']:raise ValueError('Audit integrity check failed; execution blocked')
        before=json.loads(json.dumps({'batteries':self.batteries,'time':self.time.isoformat(),'spent':self.spent,'revenue':self.revenue,
            'learner':self.learner.__dict__,'latest_forecast':self.latest_forecast,'forecast_errors':self.forecast_errors,'health_observations':self.health_observations,'decision_status':d['status']}))
        actual=out['state']['solar_mw']+out['state']['wind_mw']
        if self.latest_forecast and self.latest_forecast['time']==out['state']['time']:
            self.forecast_errors.append(actual-self.latest_forecast['renewable_mw']); self.forecast_errors=self.forecast_errors[-192:]
        self.learner.update(features(out['state']),actual-out['baseline_mw'])
        self.latest_forecast=out['forecast']['steps'][0]
        for b,soc,p in zip(self.batteries,a['soc_after_mwh'],a['battery_mw']):
            b['soc']=soc; b['health']=max(.5,b['health']-abs(p)*DT*.00001)
            series=self.health_observations.setdefault(b['id'],[])
            hours=(series[-1][0]+DT) if series else DT;series.append([hours,b['health']]);self.health_observations[b['id']]=series[-1000:]
        self.spent+=a['purchase_inr']+a['degradation_inr']; self.revenue+=a['revenue_inr']
        self.time+=timedelta(minutes=15); d['status']='EXECUTED_SIMULATION'
        out['verification']={'balance_error_mw':out['state']['solar_mw']+out['state']['wind_mw']+sum(a['battery_mw'])+a['import_mw']+a['unserved_mw']-out['state']['demand_mw']-a['export_mw']-a['curtailment_mw'], 'soc_bounds_ok':True}
        out['checkpoint']={'time':self.time.isoformat(),'batteries':self.batteries,'spent':self.spent,'revenue':self.revenue,'assets':self.assets,
                           'learning':{'weights':self.learner.weights,'samples':self.learner.samples,'errors':self.learner.errors},
                           'latest_forecast':self.latest_forecast,'forecast_errors':self.forecast_errors}
        out['checkpoint'].update({'health_observations':self.health_observations,'budget':self.budget,'emergency_stop':self.emergency_stop})
        if request_meta:out['request_idempotency_key']=request_meta['key']
        previous=self.db.execute('SELECT hash FROM audit ORDER BY seq DESC LIMIT 1').fetchone()
        previous=previous[0] if previous else 'GENESIS'; payload=json.dumps(out,sort_keys=True,allow_nan=False)
        try:
            self.db.execute('INSERT INTO audit(previous,payload,hash) VALUES(?,?,?)',(previous,payload,digest({'previous':previous,'payload':payload})))
            if request_meta:
                self.db.execute('INSERT INTO requests(key,route,body_hash,result) VALUES(?,?,?,?)',(request_meta['key'],request_meta['route'],request_meta['body_hash'],payload))
            self.db.commit()
        except sqlite3.Error as error:
            self.db.rollback();self.batteries=before['batteries'];self.time=datetime.fromisoformat(before['time']);self.spent=before['spent'];self.revenue=before['revenue']
            self.learner.__dict__.update(before['learner']);self.latest_forecast=before['latest_forecast'];self.forecast_errors=before['forecast_errors'];self.health_observations=before['health_observations']
            d['status']=before['decision_status'];out.pop('checkpoint',None);out.pop('verification',None)
            raise ValueError('Dispatch persistence failed; simulation state restored') from error
        # freeze history so later asset updates cannot rewrite old observations
        self.history.append(json.loads(payload)); self.history=self.history[-192:]; self.pending=None
        return out

    def control(self,event,detail):
        body=json.dumps({'event':event,'detail':detail,'recorded_at':datetime.now(timezone.utc).isoformat()},sort_keys=True,allow_nan=False)
        row=self.db.execute('SELECT hash FROM controls ORDER BY seq DESC LIMIT 1').fetchone();previous=row[0] if row else 'GENESIS'
        self.db.execute('INSERT INTO controls(previous,payload,hash) VALUES(?,?,?)',(previous,body,digest({'previous':previous,'payload':body})));self.db.commit()

    def research_report(self,current=None):
        current=current or self.pending or (self.history[-1] if self.history else None)
        if current is None:return {'status':'NO_STATE'}
        s=current['state'];d=current['decision'];report={'neural_forecast_demo':self.neural_model.report(s),'graph':network_report(self.assets,s,d.get('selected')),
            'phm':[phm(b['id'],self.health_observations.get(b['id'],[])) for b in self.batteries],
            'failure_posterior':bayesian_rate(sum(h['decision']['selected']['unserved_mw']>1e-6 for h in self.history),len(self.history)),
            'satellite_advection_demo':motion_nowcast(**{k:v for k,v in demo_clouds().items() if k!='source'})}
        if 'selected' in d:
            report['financial_risk']=financial_risk(s,d['selected'])
            report['qubo_benchmark']=benchmark(d['alternatives'])
        return report

    def audit(self):
        previous='GENESIS'; count=0
        for seq,prev,payload,h in self.db.execute('SELECT * FROM audit ORDER BY seq'):
            if prev!=previous or digest({'previous':prev,'payload':payload})!=h: return {'integrity':False,'failed_sequence':seq}
            previous=h; count+=1
        main_head=previous;control_count=0;previous='GENESIS'
        for seq,prev,payload,h in self.db.execute('SELECT * FROM controls ORDER BY seq'):
            if prev!=previous or digest({'previous':prev,'payload':payload})!=h:return {'integrity':False,'failed_control_sequence':seq}
            previous=h;control_count+=1
        return {'integrity':True,'events':count,'head':main_head,'control_events':control_count,'control_head':previous,'type':'local SHA-256 hash chains; no distributed blockchain'}

    def analysis(self):
        n=len(self.history)
        return {'window_intervals':n,'emergency_stop':self.emergency_stop,'learning':self.learner.metrics(),'residual_control_chart':control_chart(self.learner.errors),
                'one_step_forecast_samples':len(self.forecast_errors),'one_step_forecast_mae_mw':sum(abs(e) for e in self.forecast_errors)/len(self.forecast_errors) if self.forecast_errors else None,
                'imported_observations':len(self.imported),'spent_inr':self.spent,'revenue_inr':self.revenue,'net_cost_inr':self.spent-self.revenue,
                'remaining_budget_inr':self.budget-self.spent,'batteries':self.batteries,
                'unserved_mwh':sum(h['decision']['selected']['unserved_mw']*DT for h in self.history),
                'carbon_kg':sum(h['decision']['selected']['carbon_kg'] for h in self.history),
                'forecast_mae_mw':sum(abs(h['state']['solar_mw']+h['state']['wind_mw']-h['baseline_mw']) for h in self.history)/n if n else None,
                'forecast_metric_note':'same-time physics baseline residual; not a held-out future forecast score',
                'alerts':[{'cause':'severe weather','effect':'wind cutout and low solar output','solution':'reserve storage and review grid purchases'}] if self.shock=='storm' else [],
                'phm':[{'asset':b['id'],'health':b['health'],'method':'synthetic throughput degradation','rul':'not calibrated; unavailable'} for b in self.batteries]}
