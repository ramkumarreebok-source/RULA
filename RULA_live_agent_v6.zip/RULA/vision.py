"""Own convolution-feature classifier; learns solely from generated demonstration images."""
import math,random,base64,struct

def decode_image(data):
    if len(data)>1024*1024: raise ValueError('Image too large (1 MiB maximum)')
    if data.startswith(b'P2'):
        text=data.decode('ascii'); tokens=[]
        for line in text.splitlines(): tokens+=line.split('#')[0].split()
        w,h,maxval=map(int,tokens[1:4])
        if not 4<=w<=256 or not 4<=h<=256 or not 1<=maxval<=65535: raise ValueError('Invalid PGM dimensions')
        pixels=[int(t) for t in tokens[4:]]
        if len(pixels)!=w*h or any(v<0 or v>maxval for v in pixels): raise ValueError('Invalid PGM pixels')
        return [[pixels[y*w+x]/maxval for x in range(w)] for y in range(h)]
    if data.startswith(b'BM'):
        if len(data)<54: raise ValueError('Invalid BMP header')
        offset=struct.unpack_from('<I',data,10)[0]; header=struct.unpack_from('<I',data,14)[0]
        if header<40: raise ValueError('Unsupported BMP header')
        w,h=struct.unpack_from('<ii',data,18); planes,bits=struct.unpack_from('<HH',data,26); compression=struct.unpack_from('<I',data,30)[0]
        if not 4<=w<=256 or not 4<=abs(h)<=256 or bits!=24 or planes!=1 or compression!=0: raise ValueError('Use uncompressed 24-bit BMP, max 256×256')
        stride=((w*3+3)//4)*4
        if offset<54 or offset+stride*abs(h)>len(data): raise ValueError('Truncated BMP')
        grid=[]
        for y in range(abs(h)):
            yy=abs(h)-1-y if h>0 else y; row=[]
            for x in range(w):
                b,g,r=data[offset+yy*stride+x*3:offset+yy*stride+x*3+3];row.append((.2126*r+.7152*g+.0722*b)/255)
            grid.append(row)
        return grid
    raise ValueError('Use ASCII PGM (P2) or uncompressed 24-bit BMP. JPEG/PNG decoding requires an external package, excluded from this core.')

def extract(grid):
    h=len(grid);w=len(grid[0]); vals=[v for r in grid for v in r];mean=sum(vals)/len(vals)
    edge=[]
    for y in range(1,h-1):
        for x in range(1,w-1):
            gx=sum(grid[y+j][x+1]*k-grid[y+j][x-1]*k for j,k in [(-1,1),(0,2),(1,1)])
            gy=sum(grid[y+1][x+j]*k-grid[y-1][x+j]*k for j,k in [(-1,1),(0,2),(1,1)])
            edge.append(min(1,math.hypot(gx,gy)/4))
    return [mean,math.sqrt(sum((v-mean)**2 for v in vals)/len(vals)),sum(v<.22 for v in vals)/len(vals),sum(edge)/len(edge),max(edge)]

def generated_image(label,rng):
    g=[[rng.uniform(.45,.7) for x in range(24)] for y in range(24)]
    if label==1:
        x=rng.randrange(5,18)
        for y in range(24): g[y][x]=.05
    if label==2:
        for y in range(5,19):
            for x in range(5,19): g[y][x]=rng.uniform(.05,.18)
    return g

class VisionModel:
    def __init__(self):
        self.labels=['demo_clean','demo_linear_defect','demo_dark_occlusion'];self.weights=[[0.]*6 for _ in self.labels]
        rng=random.Random(271);train=[(extract(generated_image(i%3,rng)),i%3) for i in range(240)]
        for _ in range(25):
            for f,label in train:
                x=[1]+f; p=self.probabilities(x)
                for i in range(3):
                    for j in range(6):self.weights[i][j]+=.2*((1 if i==label else 0)-p[i])*x[j]
        held=[(extract(generated_image(i%3,rng)),i%3) for i in range(90)]
        self.accuracy=sum(max(range(3),key=lambda k:self.probabilities([1]+f)[k])==label for f,label in held)/90
    def probabilities(self,x):
        logits=[sum(w*v for w,v in zip(row,x)) for row in self.weights];m=max(logits);e=[math.exp(v-m) for v in logits];return [v/sum(e) for v in e]
    def inspect(self,data):
        grid=decode_image(data);f=extract(grid);p=self.probabilities([1]+f)
        return {'label':self.labels[max(range(3),key=lambda i:p[i])],'scores':dict(zip(self.labels,p)),'features':f,
                'training_source':'240 generated images','heldout_demo_accuracy':self.accuracy,'heldout_demo_count':90,
                'method':'fixed Sobel convolution features + own trained softmax head',
                'operational_validity':'UNVALIDATED_ON_REAL_ASSETS','action':'manual image review only; no automatic shutdown'}
