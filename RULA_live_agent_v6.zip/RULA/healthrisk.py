"""Own-code PHM trends, Bayesian event rates, Monte Carlo risk and network signals."""
import math,random
from neural import graph_head

def phm(asset_id,observations,threshold=.8):
    # [(operating_hours,health_fraction),...] with monotonically increasing hours
    if len(observations)<3:return {'asset':asset_id,'status':'INSUFFICIENT_DATA','rul_hours':None}
    if len(observations)>1000:raise ValueError('Too many health observations')
    x=[float(v[0]) for v in observations];y=[float(v[1]) for v in observations]
    if any(not math.isfinite(v) or v<0 for v in x) or any(not math.isfinite(v) or not 0<=v<=1 for v in y) or any(x[i]>=x[i+1] for i in range(len(x)-1)):raise ValueError('Invalid health times/values')
    mx=sum(x)/len(x);my=sum(y)/len(y);sxx=sum((v-mx)**2 for v in x)
    slope=sum((a-mx)*(b-my) for a,b in zip(x,y))/sxx;intercept=my-slope*mx
    residual=math.sqrt(sum((b-(intercept+slope*a))**2 for a,b in zip(x,y))/max(1,len(x)-2))
    slope_se=residual/math.sqrt(sxx);lower=slope-1.96*slope_se;upper=slope+1.96*slope_se
    current=y[-1]
    def remaining(rate):return max(0,(threshold-current)/rate) if rate<0 else None
    return {'asset':asset_id,'status':'TREND_ESTIMATE','health':current,'threshold':threshold,'slope_per_hour':slope,'rul_hours':remaining(slope),
            'rul_low_hours':remaining(lower),'rul_high_hours':remaining(upper),'slope_standard_error':slope_se,
            'method':'linear degradation extrapolation; heuristic slope interval; requires monotonic operating-hour data',
            'validation':'not calibrated for actual assets or failure modes'}

def bayesian_rate(events,exposures):
    if not isinstance(events,int) or not isinstance(exposures,int) or not 0<=events<=exposures:raise ValueError('Invalid event counts')
    a=1+events;b=1+exposures-events;mean=a/(a+b);sd=math.sqrt(a*b/((a+b)**2*(a+b+1)))
    return {'prior':'Beta(1,1)','posterior_alpha':a,'posterior_beta':b,'event_probability':mean,
            'approx_lower':max(0,mean-1.96*sd),'approx_upper':min(1,mean+1.96*sd),'interval_method':'normal approximation; not exact credible interval'}

def financial_risk(state,action,samples=256,seed=11):
    rng=random.Random(seed);losses=[];shortages=0
    for _ in range(samples):
        renewable=max(0,(state['solar_mw']+state['wind_mw'])*(1+rng.gauss(0,.15)))
        demand=max(0,state['demand_mw']*(1+rng.gauss(0,.05)))
        price=max(0,state['buy_inr_kwh']*(1+rng.gauss(0,.2)))
        net=demand-renewable-sum(action['battery_mw']);imported=min(max(0,net),state['grid_limit_mw'])
        shortage=max(0,net-imported);shortages+=shortage>1e-6
        loss=imported*.25*1000*price-min(max(0,-net),state['grid_limit_mw'])*.25*1000*state['sell_inr_kwh']+shortage*.25*1000000
        losses.append(loss)
    losses.sort();idx=max(0,math.ceil(.95*samples)-1);tail=losses[idx:]
    return {'samples':samples,'mean_cost_and_shortage_penalty_inr':sum(losses)/samples,'var95_inr':losses[idx],
            'cvar95_inr':sum(tail)/len(tail),'shortage_frequency':shortages/samples,
            'assumptions':'independent Gaussian generation 15%, demand 5%, buy price 20%; illustrative, not calibrated market risk'}

def network_report(assets,state,action=None):
    nodes=[a['id'] for a in assets]+['BESS-1','BESS-2','LOAD','GRID'];hub='BUS'
    capacities={a['id']:a['capacity_mw'] for a in assets}
    limits={**capacities,'BESS-1':5.,'BESS-2':5.,'LOAD':200.,'GRID':state['grid_limit_mw']}
    edges=[{'from':n,'to':hub,'limit_mw':limits[n]} for n in nodes]
    if action:
        total=state['solar_mw']+state['wind_mw'];curtail_fraction=action['curtailment_mw']/total if total else 0.
        injections={a['id']:a['output_mw']*(1-curtail_fraction) for a in state['assets']}
        injections.update({'BESS-1':action['battery_mw'][0],'BESS-2':action['battery_mw'][1],
                           'LOAD':-(state['demand_mw']-action['unserved_mw']),'GRID':action['import_mw']-action['export_mw']})
        for edge in edges:
            flow=injections[edge['from']];edge.update({'flow_to_bus_mw':flow,'overloaded':abs(flow)>edge['limit_mw']+1e-8,
                                                     'leaf_angle_rad':flow/100.,'susceptance_mw_per_rad':100.})
        balance=sum(injections.values())
    else:balance=None

    renewable=state['solar_mw']+state['wind_mw'];signals={a['id']:max(0,1-a['output_mw']/a['capacity_mw']) for a in state['assets']}
    signals.update({'BESS-1':.2,'BESS-2':.2,'LOAD':min(1,max(0,(state['demand_mw']-renewable)/max(1,state['demand_mw']))),'GRID':1-min(1,state['grid_limit_mw']/30),'BUS':0.})
    initial=dict(signals)
    for _ in range(3):
        new={}
        for n in signals:
            neighbors=nodes if n==hub else [hub]
            new[n]=.7*initial[n]+.3*sum(signals[v] for v in neighbors)/len(neighbors)
        signals=new
    return {'nodes':nodes+[hub],'edges':edges,'risk_signals':signals,'learned_demo_class_scores':graph_head.infer(initial,signals,nodes+[hub]),
            'method':'three-step fixed graph message passing + own trained logistic node head; demonstration GNN',
            'training_source':'360 generated node-feature samples; 120 synthetic holdout samples','heldout_demo_accuracy':graph_head.accuracy,
            'validity':'unvalidated on actual topology; output-gap signals also rise normally at night and are not fault diagnoses','topology_source':'synthetic star network',
            'bus_balance_error_mw':balance,'overloaded_lines':[e['from'] for e in edges if e.get('overloaded')],
            'power_flow':'lossless radial star DC flow, bus angle zero, assumed 100 MW/rad line susceptance; no meshed or AC flow'}
