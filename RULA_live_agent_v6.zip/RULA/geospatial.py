"""Geographic solar position, terrain shading and raster cloud-motion nowcasts."""
import math, calendar
from datetime import datetime,timezone

def solar_position(time,latitude,longitude):
    t=time.astimezone(timezone.utc); hour=t.hour+t.minute/60+t.second/3600
    gamma=2*math.pi/(366 if calendar.isleap(t.year) else 365)*(t.timetuple().tm_yday-1+(hour-12)/24)
    eq=229.18*(.000075+.001868*math.cos(gamma)-.032077*math.sin(gamma)-.014615*math.cos(2*gamma)-.040849*math.sin(2*gamma))
    decl=.006918-.399912*math.cos(gamma)+.070257*math.sin(gamma)-.006758*math.cos(2*gamma)+.000907*math.sin(2*gamma)-.002697*math.cos(3*gamma)+.00148*math.sin(3*gamma)
    ha=math.radians(((hour*60+eq+4*longitude)%1440)/4-180); lat=math.radians(latitude)
    cosz=max(-1,min(1,math.sin(lat)*math.sin(decl)+math.cos(lat)*math.cos(decl)*math.cos(ha)))
    elevation=90-math.degrees(math.acos(cosz))
    azimuth=(math.degrees(math.atan2(math.sin(ha),math.cos(ha)*math.sin(lat)-math.tan(decl)*math.cos(lat)))+180)%360
    return {'elevation_deg':elevation,'azimuth_deg':azimuth,'cos_zenith':max(0,cosz),'equation_of_time_min':eq}

def terrain_shading(elevation_deg,horizon_deg):
    if not 0<=horizon_deg<=90: raise ValueError('Horizon must be 0–90 degrees')
    return 0. if elevation_deg<=horizon_deg else 1.

def validate_grid(grid):
    if not isinstance(grid,list) or not 4<=len(grid)<=64: raise ValueError('Grid height 4–64 required')
    w=len(grid[0]) if isinstance(grid[0],list) else 0
    if not 4<=w<=64 or any(not isinstance(row,list) or len(row)!=w for row in grid): raise ValueError('Rectangular grid width 4–64 required')
    for row in grid:
        for value in row:
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=1: raise ValueError('Cloud raster values must be finite fractions 0–1')
    return len(grid),w

def motion_nowcast(previous,current,interval_minutes=15,pixel_km=2.,horizon_minutes=60):
    h,w=validate_grid(previous)
    if validate_grid(current)!=(h,w): raise ValueError('Raster dimensions must match')
    if not 1<=interval_minutes<=120 or not .01<=pixel_km<=100 or not 1<=horizon_minutes<=120: raise ValueError('Invalid raster timing/resolution')
    best=None
    for dy in range(-3,4):
        for dx in range(-3,4):
            errors=[]
            for y in range(h):
                for x in range(w):
                    yy,xx=y-dy,x-dx
                    if 0<=yy<h and 0<=xx<w: errors.append(abs(current[y][x]-previous[yy][xx]))
            # Favor coverage and low speed when matching scores tie.
            value=(sum(errors)/len(errors),-(len(errors)/(h*w)),abs(dx)+abs(dy))
            if best is None or value<best[0]: best=(value,dx,dy)
    _,dx,dy=best; shiftx=round(dx*horizon_minutes/interval_minutes); shifty=round(dy*horizon_minutes/interval_minutes)
    predicted=[]; known=0
    for y in range(h):
        row=[]
        for x in range(w):
            yy,xx=y-shifty,x-shiftx
            if 0<=yy<h and 0<=xx<w: row.append(current[yy][xx]); known+=1
            else: row.append(None)
        predicted.append(row)
    return {'dx_pixels':dx,'dy_pixels':dy,'east_km_h':dx*pixel_km*60/interval_minutes,'south_km_h':dy*pixel_km*60/interval_minutes,
            'match_mae':best[0][0],'horizon_minutes':horizon_minutes,'predicted_cloud_fraction':predicted,
            'coverage_fraction':known/(w*h),'method':'own translation search + advection; borders unknown; no trained optical flow'}

def demo_clouds():
    previous=[[.1]*16 for _ in range(16)]; current=[[.1]*16 for _ in range(16)]
    for y in range(5,10):
        for x in range(3,8): previous[y][x]=.9;current[y][x+1]=.9
    return {'previous':previous,'current':current,'interval_minutes':15,'pixel_km':2,'horizon_minutes':30,'source':'SYNTHETIC_DEMO'}

def site_nowcast(pair,nowcast,assets,observation_time,bounds):
    """Map a geographic cloud raster to per-site illustrative generation ramps."""
    from datetime import timedelta
    south,north,west,east=[float(bounds[k]) for k in ['south','north','west','east']]
    if not all(math.isfinite(v) for v in [south,north,west,east]) or not -90<=south<north<=90 or not -180<=west<east<=180:raise ValueError('Invalid geographic raster bounds')
    current=pair['current'];h,w=validate_grid(current);future=nowcast['predicted_cloud_fraction'];out=[]
    future_time=observation_time+timedelta(minutes=nowcast['horizon_minutes'])
    for asset in assets:
        if asset['kind']!='solar':continue
        lat=asset['latitude'];lon=asset['longitude']
        if not south<=lat<=north or not west<=lon<=east:
            out.append({'asset':asset['id'],'status':'OUTSIDE_RASTER'});continue
        x=round((lon-west)/(east-west)*(w-1));y=round((north-lat)/(north-south)*(h-1));cloud=future[y][x]
        if cloud is None:
            out.append({'asset':asset['id'],'status':'UNKNOWN_ADVECTED_BOUNDARY'});continue
        nowpos=solar_position(observation_time,lat,lon);later=solar_position(future_time,lat,lon)
        base=asset['capacity_mw']*asset['health']
        before=base*nowpos['cos_zenith']*(1-current[y][x])*terrain_shading(nowpos['elevation_deg'],asset.get('horizon_deg',0))
        after=base*later['cos_zenith']*(1-cloud)*terrain_shading(later['elevation_deg'],asset.get('horizon_deg',0))
        out.append({'asset':asset['id'],'status':'MODEL_ESTIMATE','pixel':[x,y],'current_cloud_fraction':current[y][x],'forecast_cloud_fraction':cloud,
                    'current_estimate_mw':before,'future_estimate_mw':after,'delta_mw':after-before,
                    'cause':'cloud advection plus geographic solar angle and horizon shading','effect':'generation ramp',
                    'response':'review battery reserve and grid purchases' if after-before<-.5 else 'monitor forecast',
                    'validity':'cloud-fraction attenuation model; not calibrated irradiance or site forecast'})
    return {'observation_time':observation_time.isoformat(),'forecast_time':future_time.isoformat(),'sites':out,'bounds':bounds}
