@echo off
where ollama >nul 2>&1
if errorlevel 1 (
 echo Install Ollama for Windows from https://ollama.com/download/windows
 echo Reopen Command Prompt after installation, then run this setup again.
 pause
 exit /b 1
)
echo Downloading llama3.2:3b for local conversational tool use.
echo This requires internet access, model storage and sufficient available RAM.
ollama pull llama3.2:3b
if errorlevel 1 (
 echo Model download failed. Check internet access and available disk space.
 pause
 exit /b 1
)
echo Model downloaded. Start RULA and select llama3.2:3b in Model Connection.
pause
