from .optimizer import choose

class RULAAgent:
    def decide(self,s,sim):
        selected, allc = choose(s,sim.battery_soc,sim.battery_capacity,sim.battery_health)
        score,name,val,cost,carbon,conf=selected
        # counterfactuals use approximate costs from all candidates
        cf={}
        for x in allc:
            cf[x[1] + "_" + str(round(x[2],1))]={"cost":round(x[3],2),"carbon_kg":round(x[4],1)}
        risk="HIGH" if s["market_buy"]>15 or sim.battery_health<.75 or sim.fault else "LOW"
        approval=risk=="HIGH"
        reason={
            "DISCHARGE":"Reduce grid dependence while meeting demand and avoid high-cost imports.",
            "CHARGE":"Store renewable surplus for future demand and market volatility.",
            "PRESERVE":"Preserve battery capacity because immediate cycling provides limited value."
        }[name]
        return {
          "state_time":sim.t.isoformat(),
          "selected":{"name":name,"value":round(val,2),"reason":reason,"risk":risk},
          "alternatives":[{"name":x[1],"value":round(x[2],2),"reason":"counterfactual alternative","risk":"MEDIUM"} for x in allc[1:]],
          "expected_cost":round(cost,2),"expected_carbon_kg":round(carbon,1),
          "confidence":round(conf,2),"requires_human_approval":approval,
          "evidence":[f"Renewable={s['solar_mw']+s['wind_mw']:.1f} MW",
                      f"Demand={s['demand_mw']:.1f} MW",f"Market buy={s['market_buy']:.2f}",
                      f"Battery health={sim.battery_health:.2f}"],
          "counterfactuals":cf
        }

    def execute(self, decision, s, sim):
        action=decision["selected"]["name"]
        value=decision["selected"]["value"]
        renewable=s["solar_mw"]+s["wind_mw"]
        net=s["demand_mw"]-renewable
        events=[]
        if action=="CHARGE":
            sim.battery_soc=min(sim.battery_capacity,sim.battery_soc+value*.92)
            sim.battery_health=max(.5,sim.battery_health-value*.0003)
            events.append(f"Charged battery by {value:.1f} MWh")
        elif action=="DISCHARGE":
            sim.battery_soc=max(0,sim.battery_soc-value)
            sim.battery_health=max(.5,sim.battery_health-value*.00025)
            events.append(f"Discharged battery by {value:.1f} MWh")
        else:
            events.append("Battery preserved")
        if sim.fault: events.append("PHM: wind-farm anomaly active; output derated")
        if sim.market_spike: events.append("Market intelligence: price-spike regime active")
        return events
