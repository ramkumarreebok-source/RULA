def evaluate(s, soc, capacity, health):
    renewable=s["solar_mw"]+s["wind_mw"]
    deficit=max(0,s["demand_mw"]-renewable)
    surplus=max(0,renewable-s["demand_mw"])
    usable_charge=min(surplus, capacity-soc)
    discharge=min(deficit,soc)

    # Candidate policies: charge surplus, discharge, buy, export, curtail.
    candidates=[]
    # 1 balanced: use renewable, charge surplus / discharge deficit
    net=s["demand_mw"]-renewable
    if net>0:
        d=min(net,soc)
        residual=net-d
        cost=residual*s["market_buy"] + d*0.12/ max(health,.5)
        carbon=residual*s["carbon_grid"]*1000
        candidates.append(("DISCHARGE",d,cost,carbon,0.92))
    else:
        c=min(-net,capacity-soc)
        export=max(0,-net-c)
        cost=-export*s["market_sell"] + c*0.12/max(health,.5)
        carbon=0
        candidates.append(("CHARGE",c,cost,carbon,0.95))

    # 2 preserve battery
    residual=max(0,net)
    export=max(0,-net)
    candidates.append(("PRESERVE",0,residual*s["market_buy"]-export*s["market_sell"],
                       residual*s["carbon_grid"]*1000,.90))
    # 3 market arbitrage / grid support
    if s["market_buy"] > 8:
        d=min(deficit,soc)
        candidates.append(("DISCHARGE",d,max(0,deficit-d)*s["market_buy"] + d*.15/max(health,.5),
                           max(0,deficit-d)*s["carbon_grid"]*1000,.86))
    return candidates

def choose(s,soc,capacity,health):
    c=evaluate(s,soc,capacity,health)
    # reliability penalty dominates when demand cannot be met
    scored=[]
    for name,val,cost,carbon,conf in c:
        reliability_penalty=0
        if name=="PRESERVE" and s["demand_mw"] > s["solar_mw"]+s["wind_mw"] and soc>0:
            reliability_penalty=18
        score=cost + carbon*.001 + reliability_penalty
        scored.append((score,name,val,cost,carbon,conf))
    scored.sort()
    return scored[0], scored
