from .simulator import Simulator
from .agent import RULAAgent
from .ml import forecaster
from .security import ledger, responsible_checks

class Engine:
    def __init__(self):
        self.sim=Simulator(); self.agent=RULAAgent(); self.history=[]
    def tick(self):
        s=self.sim.advance(); forecaster.update(s); d=self.agent.decide(s,self.sim); events=self.agent.execute(d,s,self.sim)
        renewable=s['solar_mw']+s['wind_mw']; used=min(renewable,s['demand_mw']); grid=max(0,s['demand_mw']-renewable); export=max(0,renewable-s['demand_mw'])
        state={**s,'timestamp':self.sim.t.isoformat(),'reliability':1 if grid<25 else .92,'battery_soc_mwh':round(self.sim.battery_soc,2),'battery_capacity_mwh':self.sim.battery_capacity,'battery_health':round(self.sim.battery_health,3),'renewable_used_mw':round(used,2),'curtailed_mw':0,'grid_import_mw':round(grid,2),'grid_export_mw':round(export,2),'operating_cost':round(d['expected_cost'],2),'carbon_kg':round(d['expected_carbon_kg'],1)}
        safety=responsible_checks(state,d); d['responsible_ai']=safety
        out={'state':state,'decision':d,'events':events,'forecast':forecaster.forecast(),'system':self.system_metrics()}
        self.history.append(out); self.history=self.history[-200:]
        ledger.append({'action':d['selected'],'risk':d['selected']['risk'],'state_time':state['timestamp'],'approval':d['requires_human_approval']})
        return out
    def system_metrics(self):
        return {'mode':'SIMULATION_LIVE','stream':'15-minute telemetry','workers':'stateless-ready','audit_integrity':ledger.verify(),'llm_enabled':__import__('rula.llm',fromlist=['llm']).llm.enabled,'active_agents':['orchestrator','forecast','PHM','market','security','MIS']}
    def current(self): return self.history[-1] if self.history else self.tick()
engine=Engine()
