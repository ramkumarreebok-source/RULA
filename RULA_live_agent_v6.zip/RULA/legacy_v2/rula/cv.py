import base64, io

def inspect_image(data: bytes):
    """Lightweight CV health screen. Uses image statistics so it remains installable without a model."""
    try:
        from PIL import Image
        import numpy as np
        im=Image.open(io.BytesIO(data)).convert('L').resize((128,128))
        a=np.asarray(im,dtype=float)
        mean=float(a.mean()); std=float(a.std()); edge=float(np.abs(np.diff(a,axis=0)).mean()+np.abs(np.diff(a,axis=1)).mean())
        anomaly = std<8 or mean<15 or mean>245
        return {'status':'ANOMALY' if anomaly else 'NORMAL','brightness':round(mean,2),'texture':round(std,2),'edge_score':round(edge,2),'model':'statistical-vision-baseline','note':'Replace with thermal/visual CNN when real imagery is connected.'}
    except Exception as e:
        return {'status':'UNAVAILABLE','error':str(e)}
