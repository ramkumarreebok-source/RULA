import math
from collections import deque

class OnlineForecaster:
    """Dependency-light online trend/seasonality forecaster for demo telemetry."""
    def __init__(self, n=32):
        self.n=n; self.history={'solar':deque(maxlen=n),'wind':deque(maxlen=n),'demand':deque(maxlen=n),'price':deque(maxlen=n)}
    def update(self,s):
        for k,src in [('solar','solar_mw'),('wind','wind_mw'),('demand','demand_mw'),('price','market_buy')]: self.history[k].append(float(s[src]))
    def _forecast(self,key):
        x=list(self.history[key])
        if not x: return {'value':0,'lower':0,'upper':0,'confidence':0}
        recent=x[-8:]
        mean=sum(recent)/len(recent)
        if len(recent)>=2:
            slope=(recent[-1]-recent[0])/(len(recent)-1)
            pred=max(0,mean+slope*2)
        else: pred=mean
        sd=(sum((v-mean)**2 for v in recent)/len(recent))**0.5
        return {'value':round(pred,2),'lower':round(max(0,pred-1.96*sd),2),'upper':round(pred+1.96*sd,2),'confidence':round(1/(1+sd/(abs(mean)+1e-6)),2)}
    def forecast(self): return {k:self._forecast(k) for k in self.history}

forecaster=OnlineForecaster()
