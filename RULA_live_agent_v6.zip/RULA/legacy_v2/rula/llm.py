import json, os, urllib.request

class LLMGateway:
    """Optional OpenAI-compatible/Ollama-style gateway. Core RULA works without it."""
    def __init__(self):
        self.base = os.getenv('RULA_LLM_BASE_URL','').rstrip('/')
        self.model = os.getenv('RULA_LLM_MODEL','local-model')
        self.api_key = os.getenv('RULA_LLM_API_KEY','')

    @property
    def enabled(self):
        return bool(self.base)

    def explain(self, state, decision, question='Explain the current decision briefly.'):
        if not self.enabled:
            return self.fallback(state, decision, question)
        prompt = {
            'role':'You are RULA, a safety-constrained renewable energy operations copilot. Use only supplied telemetry and decision evidence. Never invent measurements. If evidence is insufficient, say so. Do not directly control physical equipment.',
            'state':state,'decision':decision,'question':question
        }
        payload=json.dumps({'model':self.model,'messages':[{'role':'system','content':prompt['role']},{'role':'user','content':json.dumps(prompt)}],'temperature':0.1}).encode()
        req=urllib.request.Request(self.base+'/v1/chat/completions',data=payload,headers={'Content-Type':'application/json'})
        if self.api_key: req.add_header('Authorization','Bearer '+self.api_key)
        try:
            with urllib.request.urlopen(req,timeout=8) as r:
                data=json.loads(r.read().decode())
            return data['choices'][0]['message']['content']
        except Exception as e:
            return self.fallback(state, decision, question)+f' [LLM gateway unavailable: {type(e).__name__}]'

    def fallback(self,state,decision,question):
        return (f"RULA selected {decision['selected']['name']} ({decision['selected']['value']:.1f} MWh). "
                f"Renewable generation is {state['solar_mw']+state['wind_mw']:.1f} MW against demand {state['demand_mw']:.1f} MW. "
                f"Confidence is {decision['confidence']:.2f}; risk is {decision['selected']['risk']}. "
                f"This explanation is grounded only in current telemetry and audit evidence.")

llm=LLMGateway()
