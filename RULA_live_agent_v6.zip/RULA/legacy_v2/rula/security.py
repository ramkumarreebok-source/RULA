import hashlib, json, os, time

class AuditLedger:
    def __init__(self): self.events=[]; self.prev='GENESIS'
    def append(self,event):
        body=json.dumps(event,sort_keys=True,default=str)
        digest=hashlib.sha256((self.prev+body).encode()).hexdigest()
        row={'ts':time.time(),'event':event,'prev_hash':self.prev,'hash':digest}
        self.prev=digest; self.events.append(row); self.events=self.events[-500:]; return row
    def verify(self):
        prev='GENESIS'
        for row in self.events:
            body=json.dumps(row['event'],sort_keys=True,default=str)
            expected=hashlib.sha256((prev+body).encode()).hexdigest()
            if expected!=row['hash'] or row['prev_hash']!=prev: return False
            prev=row['hash']
        return True

ledger=AuditLedger()

def responsible_checks(state,decision):
    reasons=[]
    if not (0<=decision.get('confidence',0)<=1): reasons.append('invalid_confidence')
    if decision.get('selected',{}).get('risk')=='HIGH': reasons.append('human_approval_required')
    if state.get('battery_health',1)<0.70: reasons.append('battery_health_guard')
    if state.get('reliability',1)<0.90: reasons.append('reliability_guard')
    return {'hallucination_guard':'telemetry-grounded','security':'audit-chain','privacy':'no_personal_data','bias':'policy_based_no_demographic_features','reliability':'guardrails_active','human_oversight':bool(reasons),'flags':reasons}
