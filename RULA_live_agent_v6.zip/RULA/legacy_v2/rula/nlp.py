import re

def interpret(text):
    t=text.lower().strip()
    intent='STATUS'
    if any(w in t for w in ['why','explain']): intent='EXPLAIN'
    elif any(w in t for w in ['forecast','predict']): intent='FORECAST'
    elif any(w in t for w in ['risk','safe','security']): intent='RISK'
    elif any(w in t for w in ['history','event','audit']): intent='AUDIT'
    elif any(w in t for w in ['simulate','what if','what-if']): intent='COUNTERFACTUAL'
    return {'intent':intent,'entities':re.findall(r'\b(?:solar|wind|battery|grid|market|phm|rula)\b',t),'normalized':t}
