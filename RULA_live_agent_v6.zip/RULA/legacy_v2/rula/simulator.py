import math, random
from datetime import datetime, timedelta, timezone

class Simulator:
    def __init__(self):
        self.t = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        self.fault = False
        self.market_spike = False
        self.battery_soc = 42.0
        self.battery_capacity = 80.0
        self.battery_health = 0.96
        self.last = None

    def snapshot(self):
        minute = self.t.hour*60 + self.t.minute
        solar_factor=max(0, math.sin((minute-360)/720*math.pi))
        solar = sum([32,28,36,25,31]) * solar_factor * random.uniform(.88,1.08)
        wind = sum([24,30,27]) * random.uniform(.55,1.0)
        if self.fault: wind *= .62
        demand = 62 + 13*math.sin((minute-420)/720*math.pi) + random.uniform(-4,4)
        buy = (7.0 + 2.5*max(0, math.sin((minute-900)/720*math.pi)) + random.uniform(-.4,.4))
        sell = buy*.72
        if self.market_spike: buy *= 2.2
        return dict(solar_mw=max(0,solar), wind_mw=max(0,wind), demand_mw=max(35,demand),
                    market_buy=max(1,buy), market_sell=max(1,sell), carbon_grid=.62)

    def advance(self):
        self.t += timedelta(minutes=15)
        return self.snapshot()

    def reset(self):
        self.__init__()
