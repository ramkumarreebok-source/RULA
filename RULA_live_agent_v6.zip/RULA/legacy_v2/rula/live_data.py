import json, os, urllib.parse, urllib.request

class LiveData:
    def __init__(self):
        # Example coordinates can be overridden per deployment; these are deliberately generic defaults.
        self.lat=float(os.getenv('RULA_LAT','13.08')); self.lon=float(os.getenv('RULA_LON','80.27'))
        self.weather_enabled=os.getenv('RULA_LIVE_WEATHER','1')=='1'
        self.market_url=os.getenv('RULA_MARKET_URL','').strip()
    def weather(self):
        if not self.weather_enabled: return {'source':'disabled'}
        q=urllib.parse.urlencode({'latitude':self.lat,'longitude':self.lon,'current':'temperature_2m,wind_speed_10m,shortwave_radiation,cloud_cover','timezone':'UTC'})
        try:
            with urllib.request.urlopen('https://api.open-meteo.com/v1/forecast?'+q,timeout=5) as r: data=json.loads(r.read().decode())
            return {'source':'Open-Meteo','current':data.get('current',{}),'retrieved':'live'}
        except Exception as e: return {'source':'Open-Meteo','status':'unavailable','error':type(e).__name__}
    def market(self):
        if not self.market_url: return {'source':'not_configured','status':'fallback_to_simulator'}
        try:
            with urllib.request.urlopen(self.market_url,timeout=5) as r: return {'source':'configured_market_feed','data':json.loads(r.read().decode()),'retrieved':'live'}
        except Exception as e: return {'source':'configured_market_feed','status':'unavailable','error':type(e).__name__}
    def snapshot(self): return {'weather':self.weather(),'market':self.market()}

live_data=LiveData()
