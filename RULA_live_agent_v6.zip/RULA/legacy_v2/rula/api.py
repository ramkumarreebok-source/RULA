from fastapi import FastAPI, UploadFile, File
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from .engine import engine
from .llm import llm
from .nlp import interpret
from .cv import inspect_image
from .security import ledger
from .live_data import live_data
from fastapi import WebSocket

app=FastAPI(title='RULA — Live Agentic Renewable Utility')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
HTML='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>RULA Live</title><style>
body{font-family:Inter,Arial;margin:0;background:#07111f;color:#e9f1ff}header{padding:18px 24px;background:#0b1b30;position:sticky;top:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;padding:18px}.card{background:#10233b;padding:16px;border-radius:14px;border:1px solid #1d3b5d}.value{font-size:25px;font-weight:700;margin-top:7px}button{background:#1c6ef2;color:white;border:0;padding:10px 14px;border-radius:9px;margin:4px;cursor:pointer}.warn{color:#ffd166}.ok{color:#65e6a1}pre{white-space:pre-wrap;max-height:380px;overflow:auto}.wide{grid-column:1/-1}input{background:#07111f;border:1px solid #31506f;color:white;padding:10px;border-radius:8px;width:70%}</style></head><body><header><h1>⚡ RULA — Live Agentic Energy Orchestrator</h1><div>Observe → Forecast → Reason → Simulate → Guard → Act → Learn</div><button onclick="tick()">Advance 15 min</button><button onclick="fault()">Toggle PHM Fault</button><button onclick="spike()">Toggle Market Spike</button></header><main><div id="cards" class="grid"></div><div class="grid"><div class="card wide"><h2>Agent Decision</h2><pre id="decision"></pre></div><div class="card"><h2>Forecast</h2><pre id="forecast"></pre></div><div class="card"><h2>Responsible AI</h2><pre id="rai"></pre></div><div class="card"><h2>System / Scale</h2><pre id="system"></pre></div><div class="card wide"><h2>NLP / LLM Copilot</h2><input id="q" value="Why did RULA choose this action?"><button onclick="ask()">Ask</button><pre id="answer"></pre></div><div class="card wide"><h2>Computer Vision</h2><input id="file" type="file" accept="image/*"><button onclick="vision()">Inspect asset image</button><pre id="cv"></pre></div></div></main><script>
let last; async function api(u,o){let r=await fetch(u,o);return r.json()} async function load(){last=await api('/api/state');render(last)} async function tick(){await api('/api/tick',{method:'POST'});load()} async function fault(){await api('/api/inject/fault',{method:'POST'});load()} async function spike(){await api('/api/inject/market-spike',{method:'POST'});load()} async function ask(){let x=await api('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:document.getElementById('q').value})});document.getElementById('answer').textContent=x.answer+'\n\nIntent: '+x.interpretation.intent} async function vision(){let f=document.getElementById('file').files[0];let fd=new FormData();fd.append('file',f);let x=await fetch('/api/vision',{method:'POST',body:fd});document.getElementById('cv').textContent=JSON.stringify(await x.json(),null,2)} function render(x){let s=x.state,d=x.decision;let a=[['Solar',s.solar_mw.toFixed(1)+' MW'],['Wind',s.wind_mw.toFixed(1)+' MW'],['Demand',s.demand_mw.toFixed(1)+' MW'],['Battery SOC',s.battery_soc_mwh.toFixed(1)+' MWh'],['Battery health',(s.battery_health*100).toFixed(1)+'%'],['Market buy','₹'+s.market_buy.toFixed(2)],['Grid import',s.grid_import_mw.toFixed(1)+' MW'],['Renewable used',s.renewable_used_mw.toFixed(1)+' MW'],['Cost','₹'+s.operating_cost.toFixed(2)],['Carbon',s.carbon_kg.toFixed(1)+' kg']];document.getElementById('cards').innerHTML=a.map(x=>`<div class="card"><div>${x[0]}</div><div class="value">${x[1]}</div></div>`).join('');document.getElementById('decision').textContent=JSON.stringify(d,null,2);document.getElementById('forecast').textContent=JSON.stringify(x.forecast,null,2);document.getElementById('rai').textContent=JSON.stringify(d.responsible_ai,null,2);document.getElementById('system').textContent=JSON.stringify(x.system,null,2)} load();setInterval(load,3000)
</script></body></html>'''

@app.get('/',response_class=HTMLResponse)
def home(): return HTML
@app.get('/api/state')
def state(): return engine.current()
@app.post('/api/tick')
def tick(): return engine.tick()
@app.post('/api/inject/fault')
def fault(): engine.sim.fault=not engine.sim.fault; return engine.current()
@app.post('/api/inject/market-spike')
def spike(): engine.sim.market_spike=not engine.sim.market_spike; return engine.current()
@app.get('/api/history')
def history(): return engine.history
@app.get('/api/live-data')
def live_feed(): return live_data.snapshot()
@app.websocket('/ws')
async def websocket(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            await ws.send_json(engine.current())
            import asyncio; await asyncio.sleep(3)
    except Exception:
        await ws.close()
@app.get('/api/audit')
def audit(): return {'integrity':ledger.verify(),'events':ledger.events[-50:]}
@app.post('/api/ask')
def ask(payload:dict):
    text=payload.get('text','status'); x=interpret(text); cur=engine.current(); return {'interpretation':x,'answer':llm.explain(cur['state'],cur['decision'],text)}
@app.post('/api/vision')
async def vision(file:UploadFile=File(...)):
    return inspect_image(await file.read())
