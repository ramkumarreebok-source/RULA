from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class Asset(BaseModel):
    id: str
    kind: str
    capacity_mw: float
    health: float = 1.0
    soc_mwh: float = 0.0
    max_energy_mwh: float = 0.0

class UtilityState(BaseModel):
    timestamp: str
    solar_mw: float
    wind_mw: float
    demand_mw: float
    market_buy: float
    market_sell: float
    carbon_grid: float
    reliability: float
    battery_soc_mwh: float
    battery_capacity_mwh: float
    battery_health: float
    renewable_used_mw: float = 0
    curtailed_mw: float = 0
    grid_import_mw: float = 0
    grid_export_mw: float = 0
    operating_cost: float = 0
    carbon_kg: float = 0

class Action(BaseModel):
    name: str
    value: float
    reason: str
    risk: str = "LOW"

class AgentDecision(BaseModel):
    state_time: str
    selected: Action
    alternatives: List[Action]
    expected_cost: float
    expected_carbon_kg: float
    confidence: float
    requires_human_approval: bool
    evidence: List[str]
    counterfactuals: Dict[str, Dict[str, float]]

class TickResponse(BaseModel):
    state: UtilityState
    decision: AgentDecision
    events: List[str]
