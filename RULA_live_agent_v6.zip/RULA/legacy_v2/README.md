# RULA — Live Agentic Renewable Energy Utility

RULA is a **research/demo-grade live agentic energy orchestration platform**. It is designed to demonstrate autonomous reasoning over renewable generation, demand, batteries, grid and market signals while exposing safety, auditability and human oversight.

## Live capabilities
- 5 solar farms, 3 wind farms, 2 BESS, industrial demand, grid and market simulation
- 15-minute live telemetry loop + dashboard auto-refresh + WebSocket stream
- Optional live weather connector (Open-Meteo) and configurable market-feed connector; simulator remains the safe fallback
- Agentic observe → forecast → reason → counterfactual → guard → act → learn loop
- ML-style online forecasting with uncertainty bands
- PHM/fault injection and reliability guardrails
- Market-spike regime detection
- LLM gateway: optional OpenAI-compatible/Ollama-style endpoint; safe deterministic fallback when no LLM is configured
- NLP intent interpretation for status/explain/forecast/risk/audit/counterfactual requests
- Computer-vision baseline endpoint for uploaded asset imagery; replaceable by a real thermal/visual CNN
- Responsible AI panel: hallucination grounding, security, privacy, bias controls, reliability and human approval flags
- Tamper-evident SHA-256 chained audit ledger
- MIS/system-scale metrics
- CORS/API separation and stateless-ready service design

## Run locally
Python 3.11+ recommended.

```bash
pip install -r requirements.txt
python run.py
```
Open `http://127.0.0.1:8000`.

The simulator advances every 3 seconds automatically. You can also manually advance 15 minutes, inject a PHM fault, or inject a market price spike.

## Live data
Set `RULA_LIVE_WEATHER=1` to enable the public weather connector. Set `RULA_LAT` and `RULA_LON` for your deployment area. For an electricity-market provider, set `RULA_MARKET_URL` to a trusted JSON endpoint; otherwise RULA deliberately uses its simulator instead of fabricating a market price.

## Optional LLM
RULA does not require an LLM to run. To connect an OpenAI-compatible local/private endpoint:

Windows PowerShell:
```powershell
$env:RULA_LLM_BASE_URL="http://localhost:11434"
$env:RULA_LLM_MODEL="your-local-model"
python run.py
```

If your provider exposes `/v1/chat/completions`, RULA will use it. Otherwise the grounded deterministic explanation remains active.

## API
- `GET /api/state` — current state, decision, forecasts, responsible-AI status
- `POST /api/tick` — advance one 15-minute interval
- `POST /api/inject/fault` — toggle PHM fault
- `POST /api/inject/market-spike` — toggle market spike
- `POST /api/ask` — NLP + LLM copilot
- `POST /api/vision` — asset image inspection baseline
- `GET /api/audit` — verify/read audit chain
- `GET /api/history` — recent decisions
- `GET /api/live-data` — live external weather/market connectors
- `WS /ws` — real-time state stream

## Responsible AI design
**Hallucination:** LLM receives telemetry + decision evidence only; fallback is deterministic.

**Security:** chained audit hashes; no credentials stored in source; high-risk actions trigger human approval.

**Privacy:** the demo contains no personal data and CV is treated as asset imagery, not identity recognition.

**Bias:** decision logic does not use demographic/protected attributes. Policies are explicit and inspectable.

**Reliability:** confidence, battery-health and grid-reliability guards; high-risk escalation; counterfactual comparison.

**Human oversight:** RULA can recommend/prepare an action, but this prototype does not directly control physical electrical equipment.

## Scalability path
For a production deployment, split the API/orchestrator into stateless services, move telemetry to Kafka/Redpanda, state/time-series data to PostgreSQL/TimescaleDB, use Redis for short-lived state/cache, object storage for images/documents, and Kubernetes/HPA for horizontal scaling. Add an API gateway, mTLS/service identity, secrets manager, model gateway, observability and policy engine.

## Important safety boundary
This is a simulation/research prototype. It must **not** be connected directly to live electrical infrastructure or used for autonomous physical switching without certified controls, protection systems, domain validation, cybersecurity review and human authorization.
