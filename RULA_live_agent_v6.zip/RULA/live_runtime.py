"""Continuous real-data advisory agent, isolated from accelerated simulation."""
import json,sqlite3,threading,time,uuid,math,copy
from datetime import datetime,timezone,timedelta
from datafeeds import timestamp,number,validate_telemetry
from geospatial import solar_position,terrain_shading
from healthrisk import financial_risk
from core import digest

class LiveRuntime:
    def __init__(self,engine,feeds,engine_lock,database='rula_live.sqlite'):
        self.engine=engine;self.feeds=feeds;self.engine_lock=engine_lock;self.lock=threading.RLock();self.cycle_lock=threading.Lock()
        self.db=sqlite3.connect(database,check_same_thread=False);self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS cycles (seq INTEGER PRIMARY KEY, previous TEXT, payload TEXT, hash TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, payload TEXT)');self.db.execute('CREATE TABLE IF NOT EXISTS configuration (key TEXT PRIMARY KEY,payload TEXT)');self.db.commit()
        if not self.audit()['integrity']:raise ValueError('Live audit integrity failed')
        self.settings={'mode':'weather','latitude':13.0827,'longitude':80.2707,'poll_seconds':60.,'demand_mw':25.,'buy_inr_kwh':7.,'sell_inr_kwh':4.,'grid_limit_mw':30.,'budget_inr':2000000.,'enabled':True}
        row=self.db.execute("SELECT payload FROM configuration WHERE key='settings'").fetchone()
        if row:self.settings.update(json.loads(row[0]))
        self.latest=None;self.telemetry=None;self.tasks={};self.thread=None;self.wake=threading.Event();self.shutdown_event=threading.Event();self.events=[];self.running=False;self.stopped=False
        row=self.db.execute('SELECT payload FROM cycles ORDER BY seq DESC LIMIT 1').fetchone()
        if row:self.latest=json.loads(row[0]);self.latest['restored_after_restart']=True
        for row in self.db.execute('SELECT id,payload FROM tasks'):self.tasks[row[0]]=json.loads(row[1])
    def configure(self,payload):
        with self.lock:
            settings=dict(self.settings)
            if 'mode' in payload:
                if payload['mode'] not in ['weather','telemetry']:raise ValueError('Mode must be weather or telemetry')
                settings['mode']=payload['mode']
            for k,lo,hi in [('latitude',-90,90),('longitude',-180,180),('poll_seconds',30,3600),('demand_mw',0,200),('buy_inr_kwh',0,100),('sell_inr_kwh',0,100),('grid_limit_mw',0,200),('budget_inr',0,1e12)]:
                if k in payload:settings[k]=number(payload[k],lo,hi,k)
            if 'enabled' in payload:
                if not isinstance(payload['enabled'],bool):raise ValueError('enabled must be boolean')
                settings['enabled']=payload['enabled']
            self.settings=settings;self.db.execute("INSERT OR REPLACE INTO configuration(key,payload) VALUES('settings',?)",(json.dumps(settings),));self.db.commit();self.wake.set()
            return settings
    def log(self,stage,message):
        with self.lock:
            self.events.append({'time':datetime.now(timezone.utc).isoformat(),'stage':stage,'message':message});self.events=self.events[-100:]
    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():return
            self.shutdown_event.clear();self.thread=threading.Thread(target=self._loop,name='rula-live-agent',daemon=True);self.thread.start()
    def close(self):
        self.shutdown_event.set();self.wake.set()
        if self.thread:self.thread.join(timeout=25)
        with self.lock:self.db.close()
    def _loop(self):
        while not self.shutdown_event.is_set():
            self.wake.clear()
            if self.settings['enabled'] and not self.stopped:
                try:self.cycle()
                except Exception as e:self.log('ERROR',type(e).__name__+': '+str(e)[:200])
            self.wake.wait(self.settings['poll_seconds'])
    def ingest(self,payload):
        with self.engine_lock:state=validate_telemetry(payload,self.engine.assets)
        supplied=payload.get('batteries')
        if not isinstance(supplied,list) or len(supplied)!=2:raise ValueError('Complete BESS observations required')
        with self.engine_lock:definitions={b['id']:copy.deepcopy(b) for b in self.engine.batteries}
        batteries=[];seen=set()
        for b in supplied:
            identity=b['id']
            if identity not in definitions or identity in seen:raise ValueError('Unknown or duplicate BESS ID')
            seen.add(identity);a=definitions[identity]
            a['soc']=number(b['soc_mwh'],a['capacity']*.1,a['capacity']*.9,'SOC');a['health']=number(b['health'],.5,1,'BESS health');batteries.append(a)
        batteries.sort(key=lambda b:b['id'])
        with self.lock:self.telemetry={'state':state,'batteries':batteries};self.wake.set()
        return {'accepted':True,'timestamp':state['time'],'mode':'LIVE_TELEMETRY_ADVISORY','execution':'no external equipment/trading connection'}
    def weather_state(self,now,weather,settings,assets,check_freshness=True):
        age=(now-timestamp(weather['observation_time'])).total_seconds()
        if check_freshness and (age>3600 or age<-120):raise ValueError('Weather is stale or future-dated; autonomous decisions blocked')
        records=weather['hourly']
        record=min(records,key=lambda p:abs((timestamp(p['time'])-now).total_seconds()))
        cloud=record['cloud_fraction'];wind10=record['wind_10m_ms'];hubwind=wind10*(100/10)**.14
        generated=[]
        for a in assets:
            # All reference assets use the configured data point; this is explicit, not a per-site SCADA claim.
            pos=solar_position(now,settings['latitude'],settings['longitude'])
            if a['kind']=='solar':factor=min(1,record['ghi_w_m2']/1000)*terrain_shading(pos['elevation_deg'],a.get('horizon_deg',0))
            else:factor=0 if hubwind>=25 else min(1,max(0,(hubwind**3-27)/(1728-27)))
            generated.append({**a,'output_mw':a['capacity_mw']*factor*a['health'],'solar_position':pos,'output_source':'WEATHER_DERIVED_ESTIMATE'})
        return {'time':now.isoformat(),'source':'LIVE_WEATHER_ESTIMATED_REFERENCE_FLEET','assets':generated,'solar_mw':sum(a['output_mw'] for a in generated if a['kind']=='solar'),
                'wind_mw':sum(a['output_mw'] for a in generated if a['kind']=='wind'),'demand_mw':settings['demand_mw'],
                'buy_inr_kwh':settings['buy_inr_kwh'],'sell_inr_kwh':settings['sell_inr_kwh'],'grid_limit_mw':settings['grid_limit_mw'],
                'cloud_fraction':cloud,'wind_ms':hubwind,'carbon_kg_kwh':.7,
                'sources':{'weather':'OPEN_METEO_WEATHER_MODEL','generation':'MODEL_ESTIMATE_NOT_SCADA','demand':'USER_CONFIGURED_ASSUMPTION','prices':'USER_CONFIGURED_TARIFF_NOT_LIVE_MARKET','bess':'REFERENCE_STORAGE_NOT_LIVE_SOC'},
                'weather_observation_time':weather['observation_time'],'weather_age_seconds':age,'radiation_time':record['time']}
    def plan(self,state,batteries,budget,future):
        with self.engine_lock:
            original=(self.engine.batteries,self.engine.spent,self.engine.budget)
            try:
                self.engine.batteries=copy.deepcopy(batteries);self.engine.spent=0;self.engine.budget=budget
                local=self.engine.optimize(state)
                if 'selected' not in local:return local
                beam=[(0.,[],copy.deepcopy(batteries),0.)]
                for step in range(8):
                    s=state if step==0 else future(step);expanded=[]
                    for score,path,bats,spent in beam:
                        self.engine.batteries=bats;self.engine.spent=spent
                        for action in self.engine.optimize(s)['alternatives']:
                            new=[{**b,'soc':soc} for b,soc in zip(bats,action['soc_after_mwh'])]
                            expanded.append((score+action['score'],path+[action],new,spent+action['purchase_inr']+action['degradation_inr']))
                    if not expanded:break
                    beam=sorted(expanded,key=lambda p:p[0])[:12]
                path=beam[0][1]
                if path:local['selected']=path[0];local['horizon_actions']=path;local['horizon_hours']=len(path)*.25
                local['status']='LIVE_RECOMMENDATION';local['reason']='First action of a constrained live-data advisory plan; never a real equipment command or exchange order.'
                return local
            finally:self.engine.batteries,self.engine.spent,self.engine.budget=original
    def cycle(self):
        if not self.cycle_lock.acquire(blocking=False):return {'status':'CYCLE_ALREADY_RUNNING'}
        try:
            with self.lock:
                if self.stopped or not self.settings['enabled']:return {'status':'PAUSED'}
                self.running=True;settings=dict(self.settings);telemetry=copy.deepcopy(self.telemetry)
                if not self.audit()['integrity']:raise ValueError('Live audit integrity failed; cycle blocked')
            now=datetime.now(timezone.utc);self.log('SENSE','Fetching or validating real-time sources')
            with self.engine_lock:assets=copy.deepcopy(self.engine.assets);bats=copy.deepcopy(self.engine.batteries)
            weather=None;satellite=None;warnings=[]
            if settings['mode']=='weather':
                weather=self.feeds.weather(settings['latitude'],settings['longitude'])
                state=self.weather_state(now,weather,settings,assets)
                future=lambda k:self.weather_state(now+timedelta(minutes=15*k),weather,settings,assets,False)
                # Forecast evaluation preserves the real source timestamp; freshness was validated against current wall time.
                forecast=[{'time':(now+timedelta(minutes=15*k)).isoformat(),**{key:self.weather_state(now+timedelta(minutes=15*k),weather,settings,assets,False)[key] for key in ['solar_mw','wind_mw']}} for k in range(1,25)]
                try:satellite=self.feeds.satellite(settings['latitude'],settings['longitude'])
                except Exception as error:warnings.append('Satellite feed unavailable: '+type(error).__name__)
                if satellite and satellite['stale_for_30min_control']:warnings.append('Satellite irradiance is delayed; excluded from current generation estimates')
            else:
                if telemetry is None:raise ValueError('Waiting for complete fresh plant telemetry; no synthetic replacement')
                age=(now-timestamp(telemetry['state']['time'])).total_seconds()
                if age>1800 or age<-120:raise ValueError('Plant telemetry expired; autonomous decisions blocked')
                state=telemetry['state'];bats=telemetry['batteries'];forecast=[]
                future=lambda k:{**state,'time':(timestamp(state['time'])+timedelta(minutes=15*k)).isoformat()}
                warnings.append('Telemetry horizon uses persistence; connect a calibrated forecast for operational horizon planning')
            self.log('FORECAST','Preparing current-condition and two-hour constrained plan')
            decision=self.plan(state,bats,settings['budget_inr'],future);risk=financial_risk(state,decision['selected']) if 'selected' in decision else None
            proposed=[]
            if 'selected' in decision:
                a=decision['selected'];proposed=[{'type':'REVIEW_DISPATCH','summary':f"Review import {a['import_mw']:.2f} MW, export {a['export_mw']:.2f} MW and battery {a['battery_mw']} MW",'authority':'APPROVAL_REQUIRED_NO_CONNECTED_ACTUATOR'}]
                if risk and risk['shortage_frequency']>.2:proposed.append({'type':'SHORTAGE_ALERT','summary':'Estimated shortage frequency exceeds 20% under illustrative stress assumptions','authority':'AUTOMATIC_INTERNAL_ALERT'})
            cycle={'id':uuid.uuid4().hex,'created_at':now.isoformat(),'mode':settings['mode'],'state':state,'decision':decision,'risk':risk,'forecast':forecast,
                   'satellite':{'latest':satellite['latest'],'age_seconds':satellite['age_seconds']} if satellite else None,'warnings':warnings,'actions':proposed,
                   'execution':'LIVE_ADVISORY_AND_INTERNAL_TASKS_ONLY','scope':'No measured energy telemetry in weather mode; no live exchange-price feed unless supplied in telemetry'}
            with self.lock:
                # Recheck stop/configuration before publishing an in-flight result.
                if self.stopped or settings!=self.settings:return {'status':'DISCARDED_AFTER_CONTROL_CHANGE'}
                row=self.db.execute('SELECT hash FROM cycles ORDER BY seq DESC LIMIT 1').fetchone();previous=row[0] if row else 'GENESIS';payload=json.dumps(cycle,sort_keys=True,allow_nan=False)
                self.db.execute('INSERT INTO cycles(previous,payload,hash) VALUES(?,?,?)',(previous,payload,digest({'previous':previous,'payload':payload})));self.db.commit();self.latest=cycle
                if hasattr(self,'last_error'):del self.last_error
                signature=digest({'interval':int(now.timestamp())//900,'source_time':state.get('weather_observation_time',state['time']),'actions':proposed})
                if proposed and not any(t.get('signature')==signature for t in self.tasks.values()):
                    self.create_task('LIVE_REVIEW',proposed[0]['summary'],cycle['id'],signature)
                    if len(proposed)>1:self.create_task('INTERNAL_ALERT',proposed[1]['summary'],cycle['id'],signature+'alert')
            self.log('ACT_VERIFY','Created internal review/alert tasks and persisted live evidence; no external command sent')
            return cycle
        except Exception as error:
            with self.lock:self.last_error={'time':datetime.now(timezone.utc).isoformat(),'message':str(error)[:300]}
            self.log('RECOVER','Cycle blocked; previous result remains historical: '+type(error).__name__)
            raise
        finally:
            with self.lock:self.running=False
            self.cycle_lock.release()
    def create_task(self,kind,summary,cycle_id=None,signature=None):
        with self.lock:
            task={'id':uuid.uuid4().hex,'kind':kind,'summary':str(summary)[:1000],'cycle_id':cycle_id,'signature':signature,'status':'PENDING_REVIEW','created_at':datetime.now(timezone.utc).isoformat(),'external_execution':False}
            self.tasks[task['id']]=task;self.db.execute('INSERT INTO tasks(id,payload) VALUES(?,?)',(task['id'],json.dumps(task)));self.db.commit();return task
    def review_task(self,identity,approve):
        with self.lock:
            if identity not in self.tasks:raise ValueError('Unknown task')
            task=self.tasks[identity]
            if task['status']!='PENDING_REVIEW':raise ValueError('Task already reviewed')
            task['status']='ACKNOWLEDGED_NO_EXTERNAL_EXECUTION' if approve else 'REJECTED';task['reviewed_at']=datetime.now(timezone.utc).isoformat()
            self.db.execute('UPDATE tasks SET payload=? WHERE id=?',(json.dumps(task),identity));self.db.commit();return task
    def stop(self,active):
        with self.lock:self.stopped=active
        # persist through enabled flag so a restart cannot silently restart the stopped loop
        self.configure({'enabled':not active});self.log('CONTROL','Paused live loop' if active else 'Resumed live loop')
    def status(self):
        with self.lock:
            now=datetime.now(timezone.utc);latest=copy.deepcopy(self.latest)
            age=(now-timestamp(latest['created_at'])).total_seconds() if latest else None
            data={'settings':dict(self.settings),'running':self.running,'loop_active':bool(self.thread and self.thread.is_alive()),'paused':self.stopped or not self.settings['enabled'],
                  'latest':latest,'age_seconds':age,'fresh':age is not None and age<max(180,self.settings['poll_seconds']*3) and not hasattr(self,'last_error'),
                  'last_error':getattr(self,'last_error',None),'tasks':list(self.tasks.values())[-50:],'events':self.events[-30:],'audit':self.audit()}
            return data
    def audit(self):
        previous='GENESIS';count=0
        for seq,prev,payload,h in self.db.execute('SELECT * FROM cycles ORDER BY seq'):
            if prev!=previous or digest({'previous':previous,'payload':payload})!=h:return {'integrity':False,'failed_sequence':seq}
            previous=h;count+=1
        return {'integrity':True,'cycles':count,'head':previous}
