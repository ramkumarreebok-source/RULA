"""Read-only grounded NLP and a small own-trained demonstration language model."""
import re,random,collections

class TinyLanguageModel:
    def __init__(self):
        self.transitions=collections.defaultdict(collections.Counter)
        texts=['review the forecast before approving a dispatch', 'review the budget before buying energy',
               'compare battery reserve and grid costs', 'check weather uncertainty and asset health',
               'preserve evidence and verify the energy balance', 'require human approval for elevated risk']
        for text in texts:
            words=['<s>']+text.split()+['</s>']
            for a,b in zip(words,words[1:]):self.transitions[a][b]+=1
    def generate(self,seed=7):
        rng=random.Random(seed);word='<s>';words=[]
        for _ in range(18):
            candidates=self.transitions[word]
            if not candidates:break
            word=rng.choices(list(candidates),weights=list(candidates.values()))[0]
            if word=='</s>':break
            words.append(word)
        return ' '.join(words).capitalize()+'.'

language_model=TinyLanguageModel()

def answer(engine,text):
    text=str(text).strip()
    if not text or len(text)>2000:raise ValueError('Question must contain 1–2000 characters')
    q=text.lower(); current=engine.pending or (engine.history[-1] if engine.history else engine.propose());state=current['state'];decision=current['decision']
    citations=['state.time='+state['time'],'state.source='+state['source']]
    if re.search(r'\b(ignore|override|execute|approve|transfer|password|secret)\b',q):
        return {'intent':'authority_boundary','answer':'The copilot is read-only. Use the explicit simulation controls for actions. It cannot override approval or reveal credentials.','evidence':citations}
    match=re.search(r'(?:drop|fall|reduce|decrease).*?(\d+(?:\.\d+)?)\s*%',q)
    if match and ('wind' in q or 'solar' in q or 'renewable' in q):
        fraction=float(match.group(1))/100
        if not 0<=fraction<=1:raise ValueError('Percentage must be 0–100')
        changed=dict(state)
        for kind in ['solar','wind']:
            if kind in q or 'renewable' in q:changed[kind+'_mw']*=1-fraction
        if 'selected' not in decision:return {'intent':'counterfactual','answer':'No feasible action is available to stress test.','evidence':citations}
        return {'intent':'counterfactual','answer':'Fixed-action counterfactual; this does not execute or replan.','data':engine.evaluate(changed,decision['selected']['battery_mw']),'evidence':citations}
    if any(w in q for w in ['budget','cost','profit','revenue','financial']):
        a=engine.analysis();body=f"Remaining gross budget: INR {a['remaining_budget_inr']:,.2f}. Spending: INR {a['spent_inr']:,.2f}; export revenue: INR {a['revenue_inr']:,.2f}. Modeled net cost: INR {a['net_cost_inr']:,.2f}."
        intent='financial';data=a
    elif any(w in q for w in ['weather','satellite','forecast','climate']):
        f=current['forecast'];body='The forecast combines geographic solar geometry, a synthetic weather profile and own online residual learning. The envelope is heuristic. Live feeds are a separate dated advisory view until connected to authorized plant telemetry.'
        intent='forecast';data=f
    elif any(w in q for w in ['health','failure','rul','risk']):
        data=engine.research_report(current);body='Risk and PHM results are model-based estimates with illustrative assumptions. They are not validated failure predictions.';intent='risk'
    else:
        data=decision;intent='explanation'
        if 'selected' in decision:
            s=decision['selected'];body=f"RULA selected battery powers {s['battery_mw']} MW, grid import {s['import_mw']:.2f} MW and export {s['export_mw']:.2f} MW. {decision['reason']} Status: {decision['status']}."
        else:body=decision['reason']
    return {'intent':intent,'answer':body,'data':data,'evidence':citations,
            'mode':'grounded templates and deterministic NLP; no pretrained LLM',
            'language_model_demo':{'model':'own six-sentence word-bigram model; not a large language model','text':language_model.generate(),'authority':'style demonstration only; contributes no numeric facts or actions'}}
