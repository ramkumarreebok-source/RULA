@echo off
cd /d "%~dp0"
where ollama >nul 2>&1
if errorlevel 1 (
 echo Install Ollama from https://ollama.com/download/windows first.
 echo After installation, reopen this launcher.
 start "Ollama installer" https://ollama.com/download/windows
 pause
 exit /b 1
)
ollama list | findstr /C:"llama3.2:3b" >nul
if errorlevel 1 (
 echo Downloading the real local language model. This may take several minutes.
 ollama pull llama3.2:3b
 if errorlevel 1 (
  echo Download failed. Check internet access and available disk space.
  pause
  exit /b 1
 )
)
set RULA_LLM_PROVIDER=ollama
set RULA_LLM_MODEL=llama3.2:3b
python launch_live.py
pause
