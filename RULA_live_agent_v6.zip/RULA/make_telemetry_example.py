"""Generate a current-time schema fixture; all readings are synthetic."""
import json
from datetime import datetime,timezone
from pathlib import Path
payload={'timestamp':datetime.now(timezone.utc).isoformat(),'provenance':'GENERATED_SCHEMA_EXAMPLE_NOT_REAL_TELEMETRY',
         'assets':[{'id':f'{kind}-{i+1}','output_mw':2.,'quality':'GOOD'} for kind,n in [('SOLAR',5),('WIND',3)] for i in range(n)],
         'batteries':[{'id':f'BESS-{i+1}','soc_mwh':10.,'health':1.} for i in range(2)],
         'demand_mw':25.,'buy_inr_kwh':7.,'sell_inr_kwh':4.,'grid_limit_mw':30.,'cloud_fraction':.4,'wind_ms':8.,'carbon_kg_kwh':.7}
path=Path(__file__).with_name('telemetry_example.json');path.write_text(json.dumps(payload,indent=2));print('Generated '+str(path))
