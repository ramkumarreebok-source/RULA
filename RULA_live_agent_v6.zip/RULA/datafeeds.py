"""Fixed-host public-data adapters and validated operational contracts, stdlib only."""
import json,math,time,urllib.request,urllib.parse,urllib.error
from datetime import datetime,timezone,timedelta

MAX_BYTES=2*1024*1024

def number(value,low,high,name):
    if isinstance(value,bool): raise ValueError(name+' must be numeric')
    result=float(value)
    if not math.isfinite(result) or not low<=result<=high: raise ValueError('Invalid '+name)
    return result

def timestamp(value):
    t=datetime.fromisoformat(str(value).replace('Z','+00:00'))
    if t.tzinfo is None: raise ValueError('Timestamp needs UTC offset')
    return t.astimezone(timezone.utc)

def validate_telemetry(payload,assets,now=None,max_age_seconds=1800):
    """Require a complete fleet snapshot; stale data cannot produce dispatch."""
    now=now or datetime.now(timezone.utc); t=timestamp(payload['timestamp'])
    age=(now-t).total_seconds()
    if age>max_age_seconds or age<-120: raise ValueError('Stale or future telemetry')
    expected={a['id']:a for a in assets}; observations=payload['assets']
    if not isinstance(observations,list) or len(observations)!=len(expected): raise ValueError('Complete configured fleet required')
    ids=set(); result=[]
    for a in observations:
        asset_id=str(a['id'])
        if asset_id not in expected or asset_id in ids: raise ValueError('Unknown or duplicate asset')
        if a.get('quality')!='GOOD': raise ValueError('Telemetry quality must be GOOD')
        ids.add(asset_id); definition=expected[asset_id]
        result.append({**definition,'output_mw':number(a['output_mw'],0,definition['capacity_mw'],'output MW')})
    return {'time':t.isoformat(),'source':'USER_TELEMETRY_ADVISORY','assets':result,
            'solar_mw':sum(a['output_mw'] for a in result if a['kind']=='solar'),
            'wind_mw':sum(a['output_mw'] for a in result if a['kind']=='wind'),
            'demand_mw':number(payload['demand_mw'],0,200,'demand MW'),
            'buy_inr_kwh':number(payload['buy_inr_kwh'],0,100,'buy price'),
            'sell_inr_kwh':number(payload['sell_inr_kwh'],0,100,'sell price'),
            'grid_limit_mw':number(payload['grid_limit_mw'],0,200,'grid limit'),
            'cloud_fraction':number(payload.get('cloud_fraction',.5),0,1,'cloud fraction'),
            'wind_ms':number(payload.get('wind_ms',8),0,100,'wind speed'),
            'carbon_kg_kwh':number(payload.get('carbon_kg_kwh',.7),0,3,'carbon factor'),
            'received_at':now.isoformat(),'age_seconds':age,'provenance':str(payload.get('provenance','user supplied'))[:200]}

class PublicFeeds:
    def __init__(self): self.cache={};self.last={}
    def _fetch(self,endpoint,params,fetcher=None):
        # Fixed endpoints only: request payload cannot supply a URL, preventing SSRF.
        url=endpoint+'?'+urllib.parse.urlencode(params);key=url;now=time.monotonic()
        if key in self.cache and now-self.cache[key][0]<600:return self.cache[key][1]
        if fetcher:raw=fetcher(url)
        else:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RULA-research/5.0'}),timeout=10) as r:
                raw=r.read(MAX_BYTES+1)
            if len(raw)>MAX_BYTES:raise ValueError('Provider response too large')
            raw=json.loads(raw)
        if not isinstance(raw,dict) or raw.get('error'):raise ValueError('Provider returned an error or invalid object')
        self.cache[key]=(now,raw);return raw
    def weather(self,lat,lon,fetcher=None):
        lat=number(lat,-90,90,'latitude');lon=number(lon,-180,180,'longitude')
        raw=self._fetch('https://api.open-meteo.com/v1/forecast',{'latitude':lat,'longitude':lon,'current':'temperature_2m,cloud_cover,wind_speed_10m',
            'hourly':'cloud_cover,wind_speed_10m,shortwave_radiation','wind_speed_unit':'ms','timezone':'UTC','forecast_days':2},fetcher)
        if raw.get('utc_offset_seconds',0)!=0:raise ValueError('Provider did not return UTC')
        units=raw.get('current_units',{});hu=raw.get('hourly_units',{})
        if units.get('wind_speed_10m')!='m/s' or hu.get('shortwave_radiation')!='W/m²':raise ValueError('Unexpected weather units')
        c=raw['current'];t=timestamp(c['time']+'Z' if not c['time'].endswith('Z') else c['time']);hourly=raw['hourly'];steps=[]
        for i,date in enumerate(hourly['time']):
            steps.append({'time':timestamp(date+'Z').isoformat(),'cloud_fraction':number(hourly['cloud_cover'][i],0,100,'cloud cover')/100,
                          'wind_10m_ms':number(hourly['wind_speed_10m'][i],0,100,'wind speed'),
                          'ghi_w_m2':number(hourly['shortwave_radiation'][i],0,1600,'radiation')})
        out={'source':'OPEN_METEO_WEATHER_MODEL','latitude':lat,'longitude':lon,'observation_time':t.isoformat(),'received_at':datetime.now(timezone.utc).isoformat(),
             'cloud_fraction':number(c['cloud_cover'],0,100,'cloud cover')/100,'wind_10m_ms':number(c['wind_speed_10m'],0,100,'wind speed'),
             'temperature_c':number(c['temperature_2m'],-100,70,'temperature'),'hourly':steps,
             'note':'Numerical weather model data, not SCADA; radiation is preceding-hour mean. Wind at 10 m requires asset-specific hub-height calibration.'}
        self.last['weather']=out;return out
    def satellite(self,lat,lon,fetcher=None):
        lat=number(lat,-90,90,'latitude');lon=number(lon,-180,180,'longitude')
        raw=self._fetch('https://satellite-api.open-meteo.com/v1/archive',{'latitude':lat,'longitude':lon,'hourly':'shortwave_radiation','timezone':'UTC','past_days':1,'models':'satellite_radiation_seamless','temporal_resolution':'native'},fetcher)
        if raw.get('hourly_units',{}).get('shortwave_radiation')!='W/m²':raise ValueError('Unexpected satellite units')
        now=datetime.now(timezone.utc); observations=[]
        for date,v in zip(raw['hourly']['time'],raw['hourly']['shortwave_radiation']):
            t=timestamp(date+'Z')
            if v is not None and t<=now: observations.append({'time':t.isoformat(),'ghi_w_m2':number(v,0,1600,'satellite irradiance')})
        if not observations:raise ValueError('No satellite coverage or no released observations for this location')
        latest=max(observations,key=lambda v:v['time']);age=(now-timestamp(latest['time'])).total_seconds()
        out={'source':'OPEN_METEO_SATELLITE_RADIATION','latitude':lat,'longitude':lon,'received_at':now.isoformat(),'latest':latest,
             'age_seconds':age,'stale_for_30min_control':age>1800,'observations':observations[-48:],
             'note':'Satellite-derived irradiance point series, not cloud imagery; provider and location can introduce 30-minute to multi-hour latency.'}
        self.last['satellite']=out;return out
