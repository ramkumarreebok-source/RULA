"""Own-code learning, statistical monitoring and validated observation contracts."""
import math, csv, io

class OnlineRegressor:
    def __init__(self, dimensions=5, rate=.02):
        self.weights=[0.]*dimensions; self.rate=rate; self.samples=0; self.errors=[]
    def predict(self, features):
        return sum(w*x for w,x in zip(self.weights,features))
    def update(self, features, target):
        prediction=self.predict(features); error=target-prediction
        norm=1+sum(x*x for x in features)
        for i,x in enumerate(features): self.weights[i]+=self.rate*error*x/norm
        self.errors.append(error); self.errors=self.errors[-192:]; self.samples+=1
        return prediction
    def metrics(self):
        return {'samples':self.samples,'pre_update_mae_mw':sum(abs(e) for e in self.errors)/len(self.errors) if self.errors else None,
                'method':'own normalized stochastic gradient linear residual model','weights':self.weights}

def features(state):
    return [1.,state['cloud_fraction'],state['wind_ms']/25.,state['solar_mw']/40.,state['wind_mw']/30.]

def control_chart(values):
    if len(values)<25: return {'status':'INSUFFICIENT_BASELINE','required':25,'available':len(values)}
    baseline=values[:25]; mean=sum(baseline)/25
    sd=math.sqrt(sum((x-mean)**2 for x in baseline)/24)
    return {'status':'READY','baseline_samples':25,'mean':mean,'std':sd,'lower_3sigma':mean-3*sd,'upper_3sigma':mean+3*sd,
            'latest':values[-1],'outside_limits':abs(values[-1]-mean)>3*sd,
            'note':'illustrative residual monitoring; independence and stationary baseline must be assessed'}

def parse_receipts(text):
    rows=list(csv.DictReader(io.StringIO(text)))
    if not 1<=len(rows)<=5000: raise ValueError('CSV must contain 1–5000 rows')
    seen=set(); result=[]
    from datetime import datetime, timezone
    for row in rows:
        required=['timestamp','asset_id','output_mw','capacity_mw','latitude','longitude']
        if any(not row.get(k) for k in required): raise ValueError('Required columns: '+','.join(required))
        t=datetime.fromisoformat(row['timestamp'].replace('Z','+00:00'))
        if t.tzinfo is None: raise ValueError('UTC offset required in timestamp')
        values={k:float(row[k]) for k in required[2:]}
        if not all(math.isfinite(v) for v in values.values()): raise ValueError('Nonfinite number')
        if not 0<=values['output_mw']<=values['capacity_mw'] or values['capacity_mw']<=0: raise ValueError('Invalid output/capacity')
        if not -90<=values['latitude']<=90 or not -180<=values['longitude']<=180: raise ValueError('Invalid coordinates')
        key=(t.astimezone(timezone.utc).isoformat(),row['asset_id'])
        if key in seen: raise ValueError('Duplicate asset observation interval')
        seen.add(key); result.append({'timestamp':key[0],'asset_id':key[1],**values})
    return result
