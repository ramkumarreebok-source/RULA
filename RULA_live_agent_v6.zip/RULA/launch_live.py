"""Start the exact v6 build on a dedicated port; open only after version verification."""
import os,sys,time,json,threading,subprocess,urllib.request,webbrowser
from pathlib import Path
root=Path(__file__).resolve().parent
port=int(os.environ.get('RULA_PORT','8010'));url=f'http://127.0.0.1:{port}'
try:
    with urllib.request.urlopen(urllib.request.Request(url+'/api/version',headers={'Authorization':'Bearer '+os.environ.get('RULA_TOKEN','')}),timeout=2) as r:existing=json.load(r)
    print(f'Port {port} already has a server ({existing.get("version","unknown version")}). Stop that server with Ctrl+C before starting this extracted build.')
    input('Press Enter to close.');sys.exit(1)
except OSError:pass

def open_when_ready():
    for _ in range(60):
        try:
            with urllib.request.urlopen(urllib.request.Request(url+'/api/version',headers={'Authorization':'Bearer '+os.environ.get('RULA_TOKEN','')}),timeout=1) as r:version=json.load(r)
            if version.get('version')=='6.0-live':webbrowser.open(url);return
        except (OSError,ValueError):pass
        time.sleep(.5)
threading.Thread(target=open_when_ready,daemon=True).start()
print('Starting RULA LIVE AGENT v6. Look for the v6 LIVE header and model connection status.',flush=True)
try:subprocess.run([sys.executable,str(root/'server.py'),'--port',str(port)],cwd=root,check=True)
except KeyboardInterrupt:pass
except subprocess.CalledProcessError:print('The server stopped with an error. Read the message above.')
